package cu.meneses.recuperamovil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Servicio "sync:" de ADB: listar carpetas, bajar y subir archivos. */
public class SyncClient {
    public static class Entry {
        public String name;
        public int mode;
        public long size;
        public long mtime;

        public boolean isDir() {
            return (mode & 0xF000) == 0x4000;
        }

        public boolean isFile() {
            return (mode & 0xF000) == 0x8000;
        }

        public boolean isLink() {
            return (mode & 0xF000) == 0xA000;
        }
    }

    public static class RemoteFailure extends IOException {
        public RemoteFailure(String m) {
            super(m);
        }
    }

    public interface Progress {
        boolean onBytes(long n); // false = cancelar
    }

    private final AdbConnection.AdbStream s;
    private final byte[] tmp4 = new byte[4];

    public SyncClient(AdbConnection c) throws IOException {
        s = c.open("sync:");
    }

    public void close() {
        s.close();
    }

    private void request(String id, byte[] payload) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(8 + payload.length).order(ByteOrder.LITTLE_ENDIAN);
        b.put(id.getBytes(StandardCharsets.US_ASCII));
        b.putInt(payload.length);
        b.put(payload);
        s.write(b.array());
    }

    private String readId() throws IOException {
        byte[] b = new byte[4];
        s.readFully(b, 4);
        return new String(b, StandardCharsets.US_ASCII);
    }

    private int readInt() throws IOException {
        s.readFully(tmp4, 4);
        return ByteBuffer.wrap(tmp4).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    private String readFail(int len) throws IOException {
        byte[] m = new byte[Math.max(0, Math.min(len, 4096))];
        s.readFully(m, m.length);
        return new String(m, StandardCharsets.UTF_8);
    }

    public List<Entry> list(String path) throws IOException {
        request("LIST", path.getBytes(StandardCharsets.UTF_8));
        List<Entry> out = new ArrayList<>();
        while (true) {
            String id = readId();
            if (id.equals("DENT")) {
                Entry e = new Entry();
                e.mode = readInt();
                e.size = readInt() & 0xffffffffL;
                e.mtime = readInt() & 0xffffffffL;
                int nl = readInt();
                byte[] nb = new byte[nl];
                s.readFully(nb, nl);
                e.name = new String(nb, StandardCharsets.UTF_8);
                out.add(e);
            } else if (id.equals("DONE")) {
                for (int i = 0; i < 4; i++) readInt();
                return out;
            } else if (id.equals("FAIL")) {
                throw new RemoteFailure(readFail(readInt()));
            } else {
                throw new IOException("Respuesta inesperada: " + id);
            }
        }
    }

    public long recv(String path, OutputStream out, Progress p) throws IOException {
        request("RECV", path.getBytes(StandardCharsets.UTF_8));
        byte[] buf = new byte[64 * 1024];
        long total = 0;
        while (true) {
            String id = readId();
            int len = readInt();
            if (id.equals("DATA")) {
                while (len > 0) {
                    int n = Math.min(len, buf.length);
                    s.readFully(buf, n);
                    out.write(buf, 0, n);
                    len -= n;
                    total += n;
                    if (p != null && !p.onBytes(n)) throw new IOException("Cancelado");
                }
            } else if (id.equals("DONE")) {
                return total;
            } else if (id.equals("FAIL")) {
                throw new RemoteFailure(readFail(len));
            } else {
                throw new IOException("Respuesta inesperada: " + id);
            }
        }
    }

    public void send(String path, InputStream in, int mtimeSec, Progress p) throws IOException {
        request("SEND", (path + ",33206").getBytes(StandardCharsets.UTF_8));
        byte[] buf = new byte[8 + 64 * 1024];
        while (true) {
            int n = in.read(buf, 8, 64 * 1024);
            if (n < 0) break;
            if (n == 0) continue;
            buf[0] = 'D';
            buf[1] = 'A';
            buf[2] = 'T';
            buf[3] = 'A';
            buf[4] = (byte) n;
            buf[5] = (byte) (n >> 8);
            buf[6] = (byte) (n >> 16);
            buf[7] = (byte) (n >> 24);
            s.write(buf, 0, 8 + n);
            if (p != null && !p.onBytes(n)) throw new IOException("Cancelado");
        }
        ByteBuffer d = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
        d.put("DONE".getBytes(StandardCharsets.US_ASCII));
        d.putInt(mtimeSec);
        s.write(d.array());
        String id = readId();
        int len = readInt();
        if (id.equals("FAIL")) throw new RemoteFailure(readFail(len));
        if (!id.equals("OKAY")) throw new IOException("Respuesta inesperada: " + id);
    }
}
