package cu.meneses.recuperamovil;

import android.app.AlertDialog;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;
import java.util.List;

/** Copias rapidas de datos y cambios de configuracion del otro movil. */
public class SettingsPage extends Page {
    private final ScrollView sv;
    private final Transfers tr;
    private final LinearLayout col;

    public SettingsPage(MainActivity m, Transfers tr) {
        super(m);
        this.tr = tr;
        sv = new ScrollView(m);
        col = Ui.vbox(m);
        int p = Ui.dp(m, 16);
        col.setPadding(p, Ui.dp(m, 4), p, p);
        sv.addView(col);

        LinearLayout copy = section("COPIA DE DATOS A ESTE MÓVIL");
        action(copy, "Contactos", R.drawable.ic_download, () -> tr.exportText("Exportando contactos", "contactos",
                "content query --uri content://com.android.contacts/data --projection display_name:data1:mimetype"));
        action(copy, "Mensajes SMS", R.drawable.ic_download, () -> tr.exportText("Exportando mensajes", "sms",
                "content query --uri content://sms --projection address:date:type:body"));
        action(copy, "Registro de llamadas", R.drawable.ic_download, () -> tr.exportText("Exportando llamadas", "llamadas",
                "content query --uri content://call_log/calls --projection number:name:date:duration:type"));
        action(copy, "Fotos y videos", R.drawable.ic_download, () -> {
            List<String> l = new ArrayList<>();
            l.add("/sdcard/DCIM");
            l.add("/sdcard/Pictures");
            l.add("/sdcard/Movies");
            tr.pullPaths("Copiando fotos y videos", l);
        });
        action(copy, "WhatsApp (chats y archivos)", R.drawable.ic_download, () -> {
            List<String> l = new ArrayList<>();
            l.add("/sdcard/Android/media/com.whatsapp/WhatsApp");
            l.add("/sdcard/WhatsApp");
            tr.pullPaths("Copiando WhatsApp", l);
        });
        action(copy, "Todo el almacenamiento interno", R.drawable.ic_download, () -> confirm(
                "Copiar todo el almacenamiento interno",
                "Puede tardar mucho y ocupar mucho espacio en este móvil. Los archivos ya copiados se omiten si repite la copia.",
                () -> {
                    List<String> l = new ArrayList<>();
                    l.add("/sdcard");
                    tr.pullPaths("Copiando todo el almacenamiento", l);
                }));

        LinearLayout screen = section("PANTALLA Y ENERGÍA");
        action(screen, "Encender pantalla", R.drawable.ic_sun, () -> run("Pantalla encendida", "input keyevent 224"));
        action(screen, "Mantener pantalla encendida", R.drawable.ic_sun, () -> run("Pantalla siempre encendida",
                "settings put global stay_on_while_plugged_in 7; settings put system screen_off_timeout 1800000"));
        action(screen, "Brillo máximo", R.drawable.ic_sun, () -> run("Brillo al máximo",
                "settings put system screen_brightness_mode 0; settings put system screen_brightness 255"));
        action(screen, "Brillo medio", R.drawable.ic_sun, () -> run("Brillo medio",
                "settings put system screen_brightness_mode 0; settings put system screen_brightness 128"));

        LinearLayout net = section("CONEXIONES");
        action(net, "Activar Wi-Fi", R.drawable.ic_sliders, () -> run("Wi-Fi activado", "svc wifi enable"));
        action(net, "Desactivar Wi-Fi", R.drawable.ic_sliders, () -> run("Wi-Fi desactivado", "svc wifi disable"));
        action(net, "Activar datos móviles", R.drawable.ic_sliders, () -> run("Datos móviles activados", "svc data enable"));
        action(net, "Desactivar datos móviles", R.drawable.ic_sliders, () -> run("Datos móviles desactivados", "svc data disable"));
        action(net, "Activar Bluetooth", R.drawable.ic_sliders, () -> run("Bluetooth activado",
                "svc bluetooth enable || cmd bluetooth_manager enable"));
        action(net, "Desactivar Bluetooth", R.drawable.ic_sliders, () -> run("Bluetooth desactivado",
                "svc bluetooth disable || cmd bluetooth_manager disable"));
        action(net, "Activar modo avión", R.drawable.ic_sliders, () -> run("Modo avión activado",
                "cmd connectivity airplane-mode enable || (settings put global airplane_mode_on 1; am broadcast -a android.intent.action.AIRPLANE_MODE)"));
        action(net, "Desactivar modo avión", R.drawable.ic_sliders, () -> run("Modo avión desactivado",
                "cmd connectivity airplane-mode disable || (settings put global airplane_mode_on 0; am broadcast -a android.intent.action.AIRPLANE_MODE)"));

        LinearLayout sys = section("SISTEMA");
        action(sys, "Abrir Ajustes", R.drawable.ic_sliders, () -> run("Ajustes abiertos", "am start -a android.settings.SETTINGS"));
        action(sys, "Ajustes de Wi-Fi", R.drawable.ic_sliders, () -> run("Ajustes de Wi-Fi abiertos", "am start -a android.settings.WIFI_SETTINGS"));
        action(sys, "Ajustes de seguridad", R.drawable.ic_lock, () -> run("Ajustes de seguridad abiertos", "am start -a android.settings.SECURITY_SETTINGS"));
        action(sys, "Opciones de desarrollador", R.drawable.ic_terminal, () -> run("Abierto", "am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS"));
        action(sys, "Reiniciar el otro móvil", R.drawable.ic_power, () -> confirm("Reiniciar",
                "El otro móvil se reiniciará y la conexión se cortará.", () -> run("Reiniciando", "reboot")));

        LinearLayout sec = section("BLOQUEO DE PANTALLA");
        action(sec, "Desbloquear con PIN", R.drawable.ic_lock, () -> main.askText("PIN del otro móvil", "PIN (solo números)", true, pin -> {
            if (pin.isEmpty()) return;
            int w = main.physW() > 0 ? Math.min(main.physW(), main.physH()) : 1080;
            int h = main.physW() > 0 ? Math.max(main.physW(), main.physH()) : 1920;
            run("Enviando PIN", "input keyevent 224; sleep 1; input swipe " + (w / 2) + " " + (int) (h * 0.85) + " " + (w / 2) + " "
                    + (int) (h * 0.2) + " 300; sleep 1; input text " + MainActivity.q(pin) + "; input keyevent 66");
        }));
        action(sec, "Quitar PIN o contraseña", R.drawable.ic_lock, () -> main.askText("Quitar bloqueo", "PIN o contraseña actual", true, pin -> {
            if (pin.isEmpty()) return;
            run("Resultado", "locksettings clear --old " + MainActivity.q(pin));
        }));
    }

    private LinearLayout section(String title) {
        LinearLayout card = Ui.card(main);
        card.addView(Ui.sectionTitle(main, title));
        LinearLayout.LayoutParams lp = Ui.lp(-1, -2);
        lp.topMargin = Ui.dp(main, 12);
        col.addView(card, lp);
        return card;
    }

    private void action(LinearLayout card, String label, int icon, Runnable r) {
        LinearLayout b = Ui.button(main, label, icon, false);
        b.setGravity(android.view.Gravity.CENTER_VERTICAL);
        b.setOnClickListener(v -> {
            if (!main.connected()) {
                main.toast("No hay móvil conectado");
                return;
            }
            r.run();
        });
        LinearLayout.LayoutParams lp = Ui.lp(-1, -2);
        lp.topMargin = Ui.dp(main, 8);
        card.addView(b, lp);
    }

    private void run(String okText, String cmd) {
        main.shellToast(okText, cmd);
    }

    private void confirm(String title, String msg, Runnable ok) {
        new AlertDialog.Builder(main).setTitle(title).setMessage(msg)
                .setPositiveButton("Continuar", (d, w) -> ok.run())
                .setNegativeButton("Cancelar", null).show();
    }

    @Override
    public View view() {
        return sv;
    }
}
