package cu.meneses.recuperamovil;

import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.util.SparseArray;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/** Protocolo ADB sobre USB (el movil de la pantalla rota es el "dispositivo", este movil es el "host"). */
public class AdbConnection {
    static final int A_SYNC = 0x434e5953;
    static final int A_CNXN = 0x4e584e43;
    static final int A_OPEN = 0x4e45504f;
    static final int A_OKAY = 0x59414b4f;
    static final int A_CLSE = 0x45534c43;
    static final int A_WRTE = 0x45545257;
    static final int A_AUTH = 0x48545541;

    public interface Listener {
        void onAuthPending();

        void onClosed();
    }

    private static class Msg {
        int cmd, a0, a1;
        byte[] data;
    }

    private final UsbDeviceConnection conn;
    private final UsbInterface intf;
    private final UsbEndpoint epIn;
    private final UsbEndpoint epOut;
    private final AdbKey key;
    private final Listener listener;
    private final Object writeLock = new Object();
    private final SparseArray<AdbStream> streams = new SparseArray<>();
    private int nextLocalId = 1;
    private volatile boolean running;
    private volatile boolean closedByUser;
    private volatile int maxPayload = 4096;
    private volatile int execMode = 0; // 0 desconocido, 1 si, 2 no
    private String banner = "";

    public AdbConnection(UsbDeviceConnection conn, UsbInterface intf, AdbKey key, Listener l) throws IOException {
        this.conn = conn;
        this.intf = intf;
        this.key = key;
        this.listener = l;
        UsbEndpoint in = null, out = null;
        for (int i = 0; i < intf.getEndpointCount(); i++) {
            UsbEndpoint ep = intf.getEndpoint(i);
            if (ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (ep.getDirection() == UsbConstants.USB_DIR_IN) in = ep;
                else out = ep;
            }
        }
        if (in == null || out == null) throw new IOException("Interfaz ADB sin puntos de datos");
        epIn = in;
        epOut = out;
    }

    public String banner() {
        return banner;
    }

    public boolean isRunning() {
        return running;
    }

    public boolean usesPty() {
        return execMode == 2;
    }

    /** Bloquea hasta que el otro movil acepte la depuracion (puede tardar mientras se muestra el aviso). */
    public void connect() throws IOException {
        running = true;
        writeMsg(A_CNXN, 0x01000000, 4096, "host::\0".getBytes(StandardCharsets.UTF_8));
        boolean sentSignature = false;
        while (true) {
            Msg m = readMsg();
            if (m.cmd == A_CNXN) {
                int md = m.a1;
                if (md < 4096) md = 4096;
                if (md > 16384) md = 16384;
                maxPayload = md;
                banner = new String(m.data, StandardCharsets.UTF_8);
                break;
            } else if (m.cmd == A_AUTH && m.a0 == 1) {
                if (!sentSignature) {
                    writeMsg(A_AUTH, 2, 0, key.sign(m.data));
                    sentSignature = true;
                } else {
                    if (listener != null) listener.onAuthPending();
                    writeMsg(A_AUTH, 3, 0, key.publicKeyBlob());
                }
            }
        }
        Thread t = new Thread(this::readerLoop, "adb-reader");
        t.setDaemon(true);
        t.start();
    }

    private void readerLoop() {
        try {
            while (running) {
                Msg m = readMsg();
                AdbStream s;
                switch (m.cmd) {
                    case A_OKAY:
                        s = find(m.a1);
                        if (s != null) s.onOkay(m.a0);
                        break;
                    case A_WRTE:
                        s = find(m.a1);
                        if (s != null) {
                            s.onData(m.data);
                            writeMsg(A_OKAY, s.localId, s.remoteId, null);
                        }
                        break;
                    case A_CLSE:
                        s = remove(m.a1);
                        if (s != null) s.onRemoteClosed();
                        break;
                    default:
                        break;
                }
            }
        } catch (IOException ignored) {
        } finally {
            running = false;
            failAll();
            if (!closedByUser && listener != null) listener.onClosed();
        }
    }

    private AdbStream find(int id) {
        synchronized (streams) {
            return streams.get(id);
        }
    }

    private AdbStream remove(int id) {
        synchronized (streams) {
            AdbStream s = streams.get(id);
            streams.remove(id);
            return s;
        }
    }

    private void failAll() {
        List<AdbStream> copy = new ArrayList<>();
        synchronized (streams) {
            for (int i = 0; i < streams.size(); i++) copy.add(streams.valueAt(i));
            streams.clear();
        }
        for (AdbStream s : copy) s.onRemoteClosed();
    }

    public void close() {
        closedByUser = true;
        running = false;
        try {
            conn.releaseInterface(intf);
        } catch (Exception ignored) {
        }
        try {
            conn.close();
        } catch (Exception ignored) {
        }
        failAll();
    }

    // ---------- transporte ----------

    private void readFully(byte[] buf, int len, int timeout, boolean retryOnTimeout) throws IOException {
        int off = 0;
        while (off < len) {
            if (!running) throw new IOException("Conexion cerrada");
            int r = conn.bulkTransfer(epIn, buf, off, len - off, timeout);
            if (r < 0) {
                if (retryOnTimeout && off == 0) continue;
                throw new IOException("USB desconectado");
            }
            off += r;
        }
    }

    private Msg readMsg() throws IOException {
        byte[] h = new byte[24];
        readFully(h, 24, 1000, true);
        ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        Msg m = new Msg();
        m.cmd = b.getInt();
        m.a0 = b.getInt();
        m.a1 = b.getInt();
        int len = b.getInt();
        b.getInt();
        int magic = b.getInt();
        if (magic != (m.cmd ^ 0xffffffff)) throw new IOException("Mensaje ADB invalido");
        if (len < 0 || len > (1 << 20)) throw new IOException("Mensaje ADB demasiado grande");
        m.data = new byte[len];
        if (len > 0) readFully(m.data, len, 5000, false);
        return m;
    }

    void writeMsg(int cmd, int a0, int a1, byte[] data) throws IOException {
        int len = data == null ? 0 : data.length;
        int sum = 0;
        for (int i = 0; i < len; i++) sum += data[i] & 0xff;
        ByteBuffer b = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(cmd).putInt(a0).putInt(a1).putInt(len).putInt(sum).putInt(cmd ^ 0xffffffff);
        synchronized (writeLock) {
            if (!running) throw new IOException("Conexion cerrada");
            int r = conn.bulkTransfer(epOut, b.array(), 24, 10000);
            if (r != 24) throw new IOException("Error de escritura USB");
            if (len > 0) {
                r = conn.bulkTransfer(epOut, data, len, 10000);
                if (r != len) throw new IOException("Error de escritura USB");
            }
        }
    }

    // ---------- flujos ----------

    public AdbStream open(String dest) throws IOException {
        AdbStream s;
        synchronized (streams) {
            s = new AdbStream(this, nextLocalId++);
            streams.put(s.localId, s);
        }
        writeMsg(A_OPEN, s.localId, 0, (dest + "\0").getBytes(StandardCharsets.UTF_8));
        try {
            if (!s.openLatch.await(10, TimeUnit.SECONDS)) {
                remove(s.localId);
                throw new IOException("Tiempo agotado al abrir " + dest);
            }
        } catch (InterruptedException e) {
            throw new IOException("Interrumpido");
        }
        if (s.openFailed) throw new IOException("No se pudo abrir " + dest);
        return s;
    }

    /** Ejecuta un comando en el otro movil. Usa "exec:" (binario limpio) y si no existe cae a "shell:". */
    public AdbStream openCommand(String cmd) throws IOException {
        if (execMode != 2) {
            try {
                AdbStream s = open("exec:" + cmd);
                execMode = 1;
                return s;
            } catch (IOException e) {
                if (!running || execMode == 1) throw e;
                execMode = 2;
            }
        }
        return open("shell:" + cmd);
    }

    void closeStream(AdbStream s) {
        AdbStream was = remove(s.localId);
        if (was != null && running && s.remoteId != 0) {
            try {
                writeMsg(A_CLSE, s.localId, s.remoteId, null);
            } catch (IOException ignored) {
            }
        }
    }

    public static class AdbStream {
        private static final byte[] EOF = new byte[0];
        final AdbConnection c;
        final int localId;
        volatile int remoteId;
        final LinkedBlockingQueue<byte[]> queue = new LinkedBlockingQueue<>();
        final Semaphore writeSem = new Semaphore(0);
        final CountDownLatch openLatch = new CountDownLatch(1);
        volatile boolean closed;
        volatile boolean openFailed;
        private byte[] cur;
        private int curOff;

        AdbStream(AdbConnection c, int localId) {
            this.c = c;
            this.localId = localId;
        }

        void onOkay(int remote) {
            if (remoteId == 0) {
                remoteId = remote;
                writeSem.release();
                openLatch.countDown();
            } else {
                writeSem.release();
            }
        }

        void onData(byte[] d) {
            if (d.length > 0) queue.offer(d);
        }

        void onRemoteClosed() {
            if (remoteId == 0) openFailed = true;
            closed = true;
            openLatch.countDown();
            queue.offer(EOF);
            writeSem.release(1000);
        }

        public boolean isClosed() {
            return closed;
        }

        public void write(byte[] b) throws IOException {
            write(b, 0, b.length);
        }

        public void write(byte[] b, int off, int len) throws IOException {
            int max = c.maxPayload;
            while (len > 0) {
                int n = Math.min(len, max);
                try {
                    if (!writeSem.tryAcquire(20, TimeUnit.SECONDS)) throw new IOException("Tiempo agotado al escribir");
                } catch (InterruptedException e) {
                    throw new IOException("Interrumpido");
                }
                if (closed) throw new IOException("Flujo cerrado");
                byte[] chunk = new byte[n];
                System.arraycopy(b, off, chunk, 0, n);
                c.writeMsg(A_WRTE, localId, remoteId, chunk);
                off += n;
                len -= n;
            }
        }

        /** Devuelve -1 al terminar, 0 si pasa el tiempo sin datos, o los bytes leidos. timeoutMs 0 = esperar. */
        public int read(byte[] b, int off, int len, long timeoutMs) throws IOException {
            while (cur == null || curOff >= cur.length) {
                byte[] n;
                try {
                    n = timeoutMs <= 0 ? queue.take() : queue.poll(timeoutMs, TimeUnit.MILLISECONDS);
                } catch (InterruptedException e) {
                    throw new IOException("Interrumpido");
                }
                if (n == null) return 0;
                if (n == EOF) {
                    queue.offer(EOF);
                    return -1;
                }
                cur = n;
                curOff = 0;
            }
            int k = Math.min(len, cur.length - curOff);
            System.arraycopy(cur, curOff, b, off, k);
            curOff += k;
            return k;
        }

        public void readFully(byte[] b, int len) throws IOException {
            int off = 0;
            while (off < len) {
                int r = read(b, off, len - off, 0);
                if (r < 0) throw new IOException("Fin inesperado del flujo");
                off += r;
            }
        }

        public InputStream input() {
            return new InputStream() {
                @Override
                public int read() throws IOException {
                    byte[] one = new byte[1];
                    int r = AdbStream.this.read(one, 0, 1, 0);
                    return r <= 0 ? -1 : (one[0] & 0xff);
                }

                @Override
                public int read(byte[] b, int off, int len) throws IOException {
                    return AdbStream.this.read(b, off, len, 0);
                }
            };
        }

        public void close() {
            if (!closed) {
                closed = true;
                c.closeStream(this);
                queue.offer(EOF);
                writeSem.release(1000);
            }
        }
    }
}
