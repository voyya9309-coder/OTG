package cu.meneses.recuperamovil;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Copia de archivos entre los dos moviles y exportacion de datos. */
public class Transfers {
    public static final int REQ_DEST = 101;
    public static final int REQ_UP_FILES = 102;
    public static final int REQ_UP_TREE = 103;

    private interface JobBody {
        void run(SyncClient sc, Stats st) throws Exception;
    }

    private static class Stats {
        long bytes;
        int files, skipped, failed;
        String current = "";
        long lastUi;
    }

    private static class Child {
        Uri uri;
        boolean dir;
        long size;
    }

    private final MainActivity a;
    private final ContentResolver cr;
    private final SharedPreferences prefs;
    private final LinearLayout overlay;
    private final TextView ovTitle;
    private final TextView ovDetail;
    private volatile boolean cancel;
    private volatile boolean busy;
    private Runnable afterDest;
    private String pendingRemoteDir;

    public Transfers(MainActivity a) {
        this.a = a;
        this.cr = a.getContentResolver();
        this.prefs = a.getSharedPreferences("recupera", Context.MODE_PRIVATE);

        overlay = Ui.vbox(a);
        overlay.setBackground(Ui.roundStroke(a, Ui.SURFACE2, Ui.ACCENT_DARK, 14));
        int p = Ui.dp(a, 12);
        overlay.setPadding(p, p, p, p);
        ovTitle = Ui.text(a, "", 14, Ui.TEXT, true);
        ovDetail = Ui.text(a, "", 12, Ui.MUTED, false);
        ovDetail.setSingleLine(true);
        ovDetail.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        ProgressBar bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        LinearLayout row = Ui.hbox(a);
        LinearLayout col = Ui.vbox(a);
        col.addView(ovTitle);
        col.addView(ovDetail);
        row.addView(col, Ui.lpWeight(0, -2, 1));
        LinearLayout cancelBtn = Ui.button(a, "Cancelar", 0, false);
        cancelBtn.setOnClickListener(v -> cancel = true);
        row.addView(cancelBtn);
        overlay.addView(row);
        LinearLayout.LayoutParams bp = Ui.lp(-1, Ui.dp(a, 6));
        bp.topMargin = Ui.dp(a, 8);
        overlay.addView(bar, bp);
        overlay.setVisibility(View.GONE);
    }

    public View overlayView() {
        return overlay;
    }

    // ---------- carpeta de destino en ESTE movil ----------

    public Uri destTree() {
        String s = prefs.getString("dest", null);
        return s == null ? null : Uri.parse(s);
    }

    public String destName() {
        Uri t = destTree();
        if (t == null) return "Sin elegir";
        String id = Uri.decode(DocumentsContract.getTreeDocumentId(t));
        int i = id.indexOf(':');
        String n = i >= 0 ? id.substring(i + 1) : id;
        return n.isEmpty() ? "Almacenamiento interno" : n;
    }

    public void chooseDest() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        a.startActivityForResult(i, REQ_DEST);
    }

    private void requireDest(Runnable then) {
        if (destTree() != null) {
            then.run();
            return;
        }
        afterDest = then;
        a.toast("Elija primero la carpeta de este movil donde se guardara todo");
        chooseDest();
    }

    public void onResult(int req, int res, Intent data) {
        if (res != MainActivity.RESULT_OK_CODE || data == null) {
            afterDest = null;
            return;
        }
        if (req == REQ_DEST) {
            Uri u = data.getData();
            if (u == null) return;
            try {
                cr.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            prefs.edit().putString("dest", u.toString()).apply();
            a.onDestChanged();
            Runnable r = afterDest;
            afterDest = null;
            if (r != null) r.run();
        } else if (req == REQ_UP_FILES) {
            List<Uri> uris = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) uris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (!uris.isEmpty()) pushFiles(uris, pendingRemoteDir);
        } else if (req == REQ_UP_TREE) {
            Uri u = data.getData();
            if (u != null) pushTree(u, pendingRemoteDir);
        }
    }

    public void pickFilesToSend(String remoteDir) {
        pendingRemoteDir = remoteDir;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        a.startActivityForResult(i, REQ_UP_FILES);
    }

    public void pickFolderToSend(String remoteDir) {
        pendingRemoteDir = remoteDir;
        a.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_UP_TREE);
    }

    // ---------- trabajos ----------

    private void runJob(String title, JobBody body) {
        if (busy) {
            a.toast("Ya hay una copia en curso");
            return;
        }
        AdbConnection c = a.adb();
        if (c == null) {
            a.toast("No hay movil conectado");
            return;
        }
        busy = true;
        cancel = false;
        overlay.setVisibility(View.VISIBLE);
        ovTitle.setText(title);
        ovDetail.setText("Preparando...");
        a.jobs.execute(() -> {
            Stats st = new Stats();
            String result;
            SyncClient sc = null;
            try {
                sc = new SyncClient(c);
                body.run(sc, st);
                result = summary(st, false);
            } catch (Exception e) {
                result = summary(st, true) + "\n\n" + (e.getMessage() == null ? e.toString() : e.getMessage());
            } finally {
                if (sc != null) sc.close();
            }
            final String msg = result;
            a.ui.post(() -> {
                busy = false;
                overlay.setVisibility(View.GONE);
                a.showMessage(title, msg);
            });
        });
    }

    private String summary(Stats st, boolean stopped) {
        return (stopped ? "Se detuvo antes de terminar.\n" : "Terminado.\n")
                + "Archivos copiados: " + st.files + "\n"
                + "Ya existentes (omitidos): " + st.skipped + "\n"
                + "Con error: " + st.failed + "\n"
                + "Datos: " + human(st.bytes) + "\n"
                + "Guardado en: " + destName() + "/RecuperaMovil/" + safeName(a.deviceName());
    }

    private void progress(Stats st, long n) {
        st.bytes += n;
        long now = System.currentTimeMillis();
        if (now - st.lastUi > 250) {
            st.lastUi = now;
            final String d = st.current + "   (" + st.files + " archivos, " + human(st.bytes) + ")";
            a.ui.post(() -> ovDetail.setText(d));
        }
    }

    private void checkCancel() throws IOException {
        if (cancel) throw new IOException("Cancelado por el usuario");
    }

    // ---------- bajar al movil de ESTE ----------

    public void pull(List<SyncClient.Entry> items, String remoteParent) {
        requireDest(() -> runJob("Copiando a este movil", (sc, st) -> {
            Uri dev = deviceFolder();
            pullItems(sc, remoteParent, items, dev, st);
        }));
    }

    public void pullPaths(String title, List<String> paths) {
        requireDest(() -> runJob(title, (sc, st) -> {
            Uri dev = deviceFolder();
            for (String p : paths) {
                checkCancel();
                int i = p.lastIndexOf('/');
                String parent = i <= 0 ? "/" : p.substring(0, i);
                String name = p.substring(i + 1);
                SyncClient.Entry e = new SyncClient.Entry();
                e.name = name;
                e.mode = 0x4000;
                List<SyncClient.Entry> one = new ArrayList<>();
                one.add(e);
                try {
                    sc.list(p);
                    pullItems(sc, parent, one, dev, st);
                } catch (SyncClient.RemoteFailure ex) {
                    st.failed++;
                }
            }
        }));
    }

    private void pullItems(SyncClient sc, String remoteParent, List<SyncClient.Entry> items, Uri destDir, Stats st) throws Exception {
        Map<String, Child> existing = listChildren(destDir);
        for (SyncClient.Entry e : items) {
            checkCancel();
            if (e.name == null || e.name.equals(".") || e.name.equals("..")) continue;
            String rpath = join(remoteParent, e.name);
            if (e.isDir()) {
                Child ex = existing.get(e.name);
                Uri nd;
                if (ex != null && ex.dir) {
                    nd = ex.uri;
                } else {
                    nd = DocumentsContract.createDocument(cr, destDir, DocumentsContract.Document.MIME_TYPE_DIR, e.name);
                }
                if (nd == null) {
                    st.failed++;
                    continue;
                }
                st.current = rpath;
                List<SyncClient.Entry> children;
                try {
                    children = sc.list(rpath);
                } catch (SyncClient.RemoteFailure rf) {
                    st.failed++;
                    continue;
                }
                List<SyncClient.Entry> useful = new ArrayList<>();
                for (SyncClient.Entry c : children) if (c.isDir() || c.isFile()) useful.add(c);
                pullItems(sc, rpath, useful, nd, st);
            } else if (e.isFile()) {
                st.current = rpath;
                Child ex = existing.get(e.name);
                if (ex != null && !ex.dir && ex.size == e.size) {
                    st.skipped++;
                    continue;
                }
                if (ex != null) {
                    try {
                        DocumentsContract.deleteDocument(cr, ex.uri);
                    } catch (Exception ignored) {
                    }
                }
                Uri u = DocumentsContract.createDocument(cr, destDir, mimeFor(e.name), e.name);
                if (u == null) {
                    st.failed++;
                    continue;
                }
                try (OutputStream os = cr.openOutputStream(u)) {
                    if (os == null) throw new IOException("No se pudo escribir");
                    sc.recv(rpath, os, n -> {
                        progress(st, n);
                        return !cancel;
                    });
                    st.files++;
                } catch (SyncClient.RemoteFailure rf) {
                    st.failed++;
                    try {
                        DocumentsContract.deleteDocument(cr, u);
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    private Uri deviceFolder() throws IOException {
        Uri tree = destTree();
        Uri root = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        Uri base = findOrCreateDir(root, "RecuperaMovil");
        return findOrCreateDir(base, safeName(a.deviceName()));
    }

    private Uri findOrCreateDir(Uri parent, String name) throws IOException {
        Child c = listChildren(parent).get(name);
        if (c != null && c.dir) return c.uri;
        Uri u;
        try {
            u = DocumentsContract.createDocument(cr, parent, DocumentsContract.Document.MIME_TYPE_DIR, name);
        } catch (Exception e) {
            throw new IOException("No se pudo crear la carpeta " + name);
        }
        if (u == null) throw new IOException("No se pudo crear la carpeta " + name);
        return u;
    }

    private Map<String, Child> listChildren(Uri docUri) {
        Map<String, Child> out = new HashMap<>();
        Uri tree = destTree();
        if (tree == null) return out;
        String id = DocumentsContract.getDocumentId(docUri);
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id);
        try (Cursor c = cr.query(kids, new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE}, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    Child ch = new Child();
                    ch.uri = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
                    ch.dir = DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2));
                    ch.size = c.isNull(3) ? -1 : c.getLong(3);
                    out.put(c.getString(1), ch);
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    // ---------- exportar texto (contactos, SMS, llamadas) ----------

    public void exportText(String title, String fileName, String command) {
        requireDest(() -> runJob(title, (sc, st) -> {
            String out = a.shell(command, 90000);
            Uri dev = deviceFolder();
            String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new java.util.Date());
            String name = fileName + "_" + stamp + ".txt";
            Uri u = DocumentsContract.createDocument(cr, dev, "text/plain", name);
            if (u == null) throw new IOException("No se pudo crear el archivo");
            try (OutputStream os = cr.openOutputStream(u)) {
                if (os == null) throw new IOException("No se pudo escribir");
                os.write(out.getBytes(StandardCharsets.UTF_8));
            }
            st.files++;
            st.bytes += out.length();
        }));
    }

    // ---------- subir al otro movil ----------

    private void pushFiles(List<Uri> uris, String remoteDir) {
        runJob("Enviando al otro movil", (sc, st) -> {
            for (Uri u : uris) {
                checkCancel();
                pushOne(sc, u, remoteDir, st);
            }
        });
    }

    private void pushOne(SyncClient sc, Uri u, String remoteDir, Stats st) throws Exception {
        String name = "archivo";
        try (Cursor c = cr.query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && c.getString(0) != null) name = c.getString(0);
        } catch (Exception ignored) {
        }
        String rpath = join(remoteDir, name);
        st.current = rpath;
        try (InputStream in = cr.openInputStream(u)) {
            if (in == null) throw new IOException("No se pudo leer " + name);
            sc.send(rpath, in, (int) (System.currentTimeMillis() / 1000), n -> {
                progress(st, n);
                return !cancel;
            });
            st.files++;
        } catch (SyncClient.RemoteFailure rf) {
            st.failed++;
        }
    }

    private void pushTree(Uri tree, String remoteDir) {
        runJob("Enviando carpeta al otro movil", (sc, st) -> {
            String rootId = DocumentsContract.getTreeDocumentId(tree);
            String n = Uri.decode(rootId);
            int i = Math.max(n.lastIndexOf('/'), n.lastIndexOf(':'));
            String rootName = i >= 0 ? n.substring(i + 1) : n;
            if (rootName.isEmpty()) rootName = "carpeta";
            String target = join(remoteDir, rootName);
            pushDir(sc, tree, rootId, target, st);
        });
    }

    private void pushDir(SyncClient sc, Uri tree, String docId, String remotePath, Stats st) throws Exception {
        checkCancel();
        a.shell("mkdir -p " + MainActivity.q(remotePath), 20000);
        List<String[]> kids = new ArrayList<>();
        Uri kidsUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        try (Cursor c = cr.query(kidsUri, new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) kids.add(new String[]{c.getString(0), c.getString(1), c.getString(2)});
            }
        }
        for (String[] k : kids) {
            checkCancel();
            if (DocumentsContract.Document.MIME_TYPE_DIR.equals(k[2])) {
                pushDir(sc, tree, k[0], join(remotePath, k[1]), st);
            } else {
                pushOne(sc, DocumentsContract.buildDocumentUriUsingTree(tree, k[0]), remotePath, st);
            }
        }
    }

    // ---------- utilidades ----------

    public static String join(String parent, String name) {
        if (parent.endsWith("/")) return parent + name;
        return parent + "/" + name;
    }

    public static String human(long b) {
        if (b < 1024) return b + " B";
        double v = b / 1024.0;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = 0;
        while (v >= 1024 && i < u.length - 1) {
            v /= 1024;
            i++;
        }
        return String.format(Locale.US, "%.1f %s", v, u[i]);
    }

    private static String mimeFor(String name) {
        int i = name.lastIndexOf('.');
        if (i > 0 && i < name.length() - 1) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(i + 1).toLowerCase(Locale.ROOT));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    public static String safeName(String s) {
        String r = s == null ? "" : s.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        return r.isEmpty() ? "Movil" : r;
    }
}
