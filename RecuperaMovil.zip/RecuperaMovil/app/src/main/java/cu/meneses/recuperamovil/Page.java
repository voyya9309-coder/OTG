package cu.meneses.recuperamovil;

import android.view.View;

public abstract class Page {
    protected final MainActivity main;

    protected Page(MainActivity main) {
        this.main = main;
    }

    public abstract View view();

    public void onShown() {
    }

    public void onHidden() {
    }

    public void onConnectionChanged(boolean connected) {
    }
}
