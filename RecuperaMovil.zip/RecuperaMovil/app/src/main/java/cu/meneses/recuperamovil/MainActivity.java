package cu.meneses.recuperamovil;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    public static final int RESULT_OK_CODE = Activity.RESULT_OK;
    private static final String ACTION_PERMISSION = "cu.meneses.recuperamovil.USB_PERMISSION";

    public final Handler ui = new Handler(Looper.getMainLooper());
    public final ExecutorService jobs = Executors.newSingleThreadExecutor();
    private final ExecutorService inputExec = Executors.newSingleThreadExecutor();
    private final ExecutorService connectExec = Executors.newSingleThreadExecutor();

    private UsbManager usb;
    private AdbKey key;
    private volatile AdbConnection adb;
    private UsbDeviceConnection usbConn;

    private String deviceName = "Movil";
    private String androidVersion = "";
    private String battery = "";
    private int physW = 0, physH = 0;

    private Transfers transfers;
    private Page[] pages;
    private LinearLayout[] navItems;
    private int currentTab = 0;
    private TextView statusChip;
    private TextView connStatus;
    private TextView connLog;
    private LinearLayout infoCard;
    private TextView infoText;
    private LinearLayout btnConnect;
    private LinearLayout btnDisconnect;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String act = intent.getAction();
            if (ACTION_PERMISSION.equals(act)) {
                UsbDevice d = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                boolean ok = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                if (d != null && ok) connectTo(d);
                else log("Permiso USB denegado");
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(act)) {
                if (adb != null || usbConn != null) {
                    log("El otro movil se desconecto");
                    disconnect();
                }
            }
        }
    };

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        usb = (UsbManager) getSystemService(Context.USB_SERVICE);
        try {
            key = new AdbKey(this);
        } catch (Exception e) {
            toast("No se pudo crear la clave de seguridad: " + e.getMessage());
        }
        transfers = new Transfers(this);
        buildUi();
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
        selectTab(0);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i != null && UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(i.getAction()) && adb == null) {
            UsbDevice d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if (d != null) requestAndConnect(d);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
        }
        disconnect();
        jobs.shutdownNow();
        inputExec.shutdownNow();
        connectExec.shutdownNow();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        transfers.onResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        if (currentTab == 2 && pages[2] instanceof FilesPage && ((FilesPage) pages[2]).goUp()) return;
        super.onBackPressed();
    }

    // ---------------------------------------------------------------- interfaz

    private void buildUi() {
        LinearLayout root = Ui.vbox(this);
        root.setBackgroundColor(Ui.BG);
        root.setFitsSystemWindows(true);

        // barra superior
        LinearLayout top = Ui.hbox(this);
        int p = Ui.dp(this, 16);
        top.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 10));
        ImageView logo = Ui.icon(this, R.drawable.ic_screen, Ui.ACCENT, 26);
        top.addView(logo);
        TextView title = Ui.text(this, "Recupera Móvil", 19, Ui.TEXT, true);
        LinearLayout.LayoutParams tp = Ui.lpWeight(0, -2, 1);
        tp.leftMargin = Ui.dp(this, 10);
        top.addView(title, tp);
        statusChip = Ui.text(this, "Sin conexión", 12, Ui.MUTED, true);
        statusChip.setBackground(Ui.round(this, Ui.SURFACE2, 20));
        statusChip.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        statusChip.setSingleLine(true);
        statusChip.setMaxWidth(Ui.dp(this, 190));
        statusChip.setEllipsize(android.text.TextUtils.TruncateAt.END);
        top.addView(statusChip);
        root.addView(top);

        // paginas
        pages = new Page[]{new ConnectPageHolder(this), new MirrorPage(this), new FilesPage(this, transfers),
                new SettingsPage(this, transfers), new TerminalPage(this)};
        FrameLayout content = new FrameLayout(this);
        for (Page pg : pages) {
            pg.view().setVisibility(View.GONE);
            content.addView(pg.view(), new FrameLayout.LayoutParams(-1, -1));
        }
        root.addView(content, Ui.lpWeight(-1, 0, 1));

        root.addView(transfers.overlayView(), marginLp(12, 6, 12, 6));

        // navegacion inferior
        LinearLayout nav = Ui.hbox(this);
        nav.setBackgroundColor(Ui.SURFACE);
        String[] labels = {"Conexión", "Pantalla", "Archivos", "Ajustes", "Terminal"};
        int[] icons = {R.drawable.ic_usb, R.drawable.ic_screen, R.drawable.ic_folder, R.drawable.ic_sliders, R.drawable.ic_terminal};
        navItems = new LinearLayout[5];
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            LinearLayout it = Ui.vbox(this);
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            it.setBackground(Ui.ripple(this, Ui.round(this, 0x00000000, 0)));
            ImageView iv = Ui.icon(this, icons[i], Ui.MUTED, 22);
            it.addView(iv);
            TextView t = Ui.text(this, labels[i], 11, Ui.MUTED, false);
            t.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = Ui.lp(-2, -2);
            lp.topMargin = Ui.dp(this, 3);
            it.addView(t, lp);
            it.setOnClickListener(v -> selectTab(idx));
            navItems[i] = it;
            nav.addView(it, Ui.lpWeight(0, -2, 1));
        }
        root.addView(nav);
        setContentView(root);
    }

    private LinearLayout.LayoutParams marginLp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = Ui.lp(-1, -2);
        lp.setMargins(Ui.dp(this, l), Ui.dp(this, t), Ui.dp(this, r), Ui.dp(this, b));
        return lp;
    }

    public void selectTab(int idx) {
        if (pages[currentTab] != null) {
            pages[currentTab].onHidden();
            pages[currentTab].view().setVisibility(View.GONE);
        }
        currentTab = idx;
        pages[idx].view().setVisibility(View.VISIBLE);
        for (int i = 0; i < navItems.length; i++) {
            int col = i == idx ? Ui.ACCENT : Ui.MUTED;
            ((ImageView) navItems[i].getChildAt(0)).setColorFilter(col);
            ((TextView) navItems[i].getChildAt(1)).setTextColor(col);
        }
        if (idx == 1) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        pages[idx].onShown();
    }

    // ---------------------------------------------------------------- pagina de conexion

    private class ConnectPageHolder extends Page {
        private final ScrollView sv;

        ConnectPageHolder(MainActivity m) {
            super(m);
            sv = new ScrollView(m);
            LinearLayout col = Ui.vbox(m);
            int p = Ui.dp(m, 16);
            col.setPadding(p, Ui.dp(m, 4), p, p);

            LinearLayout hero = Ui.card(m);
            LinearLayout hr = Ui.hbox(m);
            ImageView ic = Ui.icon(m, R.drawable.ic_usb, Ui.ACCENT, 40);
            hr.addView(ic);
            LinearLayout ht = Ui.vbox(m);
            ht.addView(Ui.text(m, "Conectar otro móvil", 18, Ui.TEXT, true));
            connStatus = Ui.text(m, "Esperando conexión por cable OTG", 13, Ui.MUTED, false);
            ht.addView(connStatus);
            LinearLayout.LayoutParams hp = Ui.lpWeight(0, -2, 1);
            hp.leftMargin = Ui.dp(m, 14);
            hr.addView(ht, hp);
            hero.addView(hr);

            LinearLayout btns = Ui.hbox(m);
            btnConnect = Ui.button(m, "Buscar y conectar", R.drawable.ic_refresh, true);
            btnConnect.setOnClickListener(v -> scanAndConnect());
            btnDisconnect = Ui.button(m, "Desconectar", 0, false);
            btnDisconnect.setOnClickListener(v -> {
                disconnect();
                log("Desconectado");
            });
            btns.addView(btnConnect, Ui.lpWeight(0, -2, 1));
            LinearLayout.LayoutParams dp2 = Ui.lp(-2, -2);
            dp2.leftMargin = Ui.dp(m, 10);
            btns.addView(btnDisconnect, dp2);
            LinearLayout.LayoutParams bl = Ui.lp(-1, -2);
            bl.topMargin = Ui.dp(m, 14);
            hero.addView(btns, bl);
            col.addView(hero);

            infoCard = Ui.card(m);
            infoCard.addView(Ui.sectionTitle(m, "DISPOSITIVO CONECTADO"));
            infoText = Ui.text(m, "", 14, Ui.TEXT, false);
            infoText.setLineSpacing(0, 1.25f);
            LinearLayout.LayoutParams il = Ui.lp(-1, -2);
            il.topMargin = Ui.dp(m, 8);
            infoCard.addView(infoText, il);
            infoCard.setVisibility(View.GONE);
            col.addView(infoCard, marginLp(0, 12, 0, 0));

            LinearLayout steps = Ui.card(m);
            steps.addView(Ui.sectionTitle(m, "CÓMO CONECTAR"));
            String[] st = {
                    "1.  Conecte el otro móvil a este con un cable USB y un adaptador OTG. Este móvil es el que lleva el adaptador.",
                    "2.  El otro móvil debe tener activada la Depuración USB (Opciones de desarrollador).",
                    "3.  Pulse Buscar y conectar y acepte el permiso USB en este móvil.",
                    "4.  La primera vez, el otro móvil muestra el aviso Permitir depuración USB. Debe aceptarlo una vez; marque Permitir siempre.",
                    "5.  Con la conexión lista use las pestañas Pantalla, Archivos, Ajustes y Terminal."
            };
            for (String s : st) {
                TextView t = Ui.text(m, s, 13, Ui.MUTED, false);
                t.setLineSpacing(0, 1.2f);
                LinearLayout.LayoutParams l = Ui.lp(-1, -2);
                l.topMargin = Ui.dp(m, 8);
                steps.addView(t, l);
            }
            col.addView(steps, marginLp(0, 12, 0, 0));

            LinearLayout logCard = Ui.card(m);
            logCard.addView(Ui.sectionTitle(m, "REGISTRO"));
            connLog = Ui.text(m, "", 12, Ui.MUTED, false);
            connLog.setTypeface(android.graphics.Typeface.MONOSPACE);
            LinearLayout.LayoutParams ll = Ui.lp(-1, -2);
            ll.topMargin = Ui.dp(m, 8);
            logCard.addView(connLog, ll);
            col.addView(logCard, marginLp(0, 12, 0, 0));

            sv.addView(col);
        }

        @Override
        public View view() {
            return sv;
        }
    }

    public void log(String s) {
        ui.post(() -> {
            if (connLog == null) return;
            String cur = connLog.getText().toString();
            String[] lines = cur.isEmpty() ? new String[0] : cur.split("\n");
            StringBuilder sb = new StringBuilder();
            int from = Math.max(0, lines.length - 7);
            for (int i = from; i < lines.length; i++) sb.append(lines[i]).append('\n');
            sb.append(s);
            connLog.setText(sb.toString());
            if (connStatus != null) connStatus.setText(s);
        });
    }

    // ---------------------------------------------------------------- USB / conexion

    private UsbInterface adbInterface(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface in = d.getInterface(i);
            if (in.getInterfaceClass() == UsbConstants.USB_CLASS_VENDOR_SPEC
                    && in.getInterfaceSubclass() == 66 && in.getInterfaceProtocol() == 1) return in;
        }
        return null;
    }

    private void scanAndConnect() {
        if (adb != null) {
            log("Ya hay un móvil conectado");
            return;
        }
        UsbDevice found = null;
        boolean anyUsb = false;
        for (UsbDevice d : usb.getDeviceList().values()) {
            anyUsb = true;
            if (adbInterface(d) != null) {
                found = d;
                break;
            }
        }
        if (found != null) {
            requestAndConnect(found);
        } else if (anyUsb) {
            log("Hay un USB conectado pero sin depuración activa. Active la Depuración USB en el otro móvil.");
        } else {
            log("No se detecta ningún móvil. Revise el cable y el adaptador OTG.");
        }
    }

    private void requestAndConnect(UsbDevice d) {
        if (usb.hasPermission(d)) {
            connectTo(d);
            return;
        }
        log("Solicitando permiso USB...");
        Intent in = new Intent(ACTION_PERMISSION).setPackage(getPackageName());
        PendingIntent pi = PendingIntent.getBroadcast(this, 0, in, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        usb.requestPermission(d, pi);
    }

    private void connectTo(UsbDevice d) {
        if (adb != null || key == null) return;
        UsbInterface intf = adbInterface(d);
        if (intf == null) {
            log("El dispositivo no tiene depuración USB activa");
            return;
        }
        log("Conectando...");
        ui.post(() -> btnConnect.setAlpha(0.5f));
        connectExec.execute(() -> {
            UsbDeviceConnection uc = usb.openDevice(d);
            if (uc == null) {
                log("No se pudo abrir el USB");
                ui.post(() -> btnConnect.setAlpha(1f));
                return;
            }
            if (!uc.claimInterface(intf, true)) {
                log("No se pudo reclamar la interfaz USB");
                uc.close();
                ui.post(() -> btnConnect.setAlpha(1f));
                return;
            }
            usbConn = uc;
            AdbConnection c;
            try {
                c = new AdbConnection(uc, intf, key, new AdbConnection.Listener() {
                    @Override
                    public void onAuthPending() {
                        log("Acepte Permitir depuración USB en el otro móvil");
                    }

                    @Override
                    public void onClosed() {
                        ui.post(() -> {
                            if (adb != null) {
                                log("Se perdió la conexión");
                                disconnect();
                            }
                        });
                    }
                });
                adb = c;
                c.connect();
            } catch (IOException e) {
                if (adb != null) log("No se pudo conectar: " + e.getMessage());
                disconnectQuiet();
                ui.post(() -> btnConnect.setAlpha(1f));
                return;
            }
            try {
                loadDeviceInfo();
            } catch (IOException ignored) {
            }
            ui.post(() -> {
                btnConnect.setAlpha(1f);
                statusChip.setText(deviceName);
                statusChip.setTextColor(Ui.OK);
                infoCard.setVisibility(View.VISIBLE);
                String res = physW > 0 ? physW + " x " + physH + " px" : "desconocida";
                infoText.setText("Equipo: " + deviceName + "\nAndroid: " + androidVersion
                        + "\nBatería: " + battery + "\nPantalla: " + res);
                log("Conectado a " + deviceName);
                for (Page pg : pages) pg.onConnectionChanged(true);
                selectTab(1);
            });
        });
    }

    private void loadDeviceInfo() throws IOException {
        String man = shell("getprop ro.product.manufacturer", 8000).trim();
        String mod = shell("getprop ro.product.model", 8000).trim();
        androidVersion = shell("getprop ro.build.version.release", 8000).trim();
        String name = (man + " " + mod).trim();
        deviceName = name.isEmpty() ? "Movil" : name;
        Matcher bm = Pattern.compile("level:\\s*(\\d+)").matcher(shell("dumpsys battery", 8000));
        battery = bm.find() ? bm.group(1) + " %" : "desconocida";
        Matcher m = null;
        String ws = shell("wm size", 8000);
        m = Pattern.compile("(\\d+)x(\\d+)").matcher(ws);
        while (m.find()) {
            physW = Integer.parseInt(m.group(1));
            physH = Integer.parseInt(m.group(2));
        }
    }

    private void disconnectQuiet() {
        AdbConnection c = adb;
        adb = null;
        if (c != null) c.close();
        UsbDeviceConnection u = usbConn;
        usbConn = null;
        if (u != null) {
            try {
                u.close();
            } catch (Exception ignored) {
            }
        }
    }

    public void disconnect() {
        boolean was = adb != null || usbConn != null;
        for (Page pg : pages) pg.onConnectionChanged(false);
        disconnectQuiet();
        ui.post(() -> {
            statusChip.setText("Sin conexión");
            statusChip.setTextColor(Ui.MUTED);
            infoCard.setVisibility(View.GONE);
            if (btnConnect != null) btnConnect.setAlpha(1f);
        });
        if (!was) return;
    }

    // ---------------------------------------------------------------- servicios para las paginas

    public AdbConnection adb() {
        AdbConnection c = adb;
        return (c != null && c.isRunning()) ? c : null;
    }

    public boolean connected() {
        return adb() != null;
    }

    public String deviceName() {
        return deviceName;
    }

    public int physW() {
        return physW;
    }

    public int physH() {
        return physH;
    }

    public void onDestChanged() {
        for (Page pg : pages) if (pg instanceof FilesPage) ((FilesPage) pg).refreshDestLabel();
    }

    public String shell(String cmd, int timeoutMs) throws IOException {
        AdbConnection c = adb();
        if (c == null) throw new IOException("No hay móvil conectado");
        AdbConnection.AdbStream s = c.openCommand(cmd);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            long end = System.currentTimeMillis() + timeoutMs;
            byte[] b = new byte[8192];
            while (true) {
                int n = s.read(b, 0, b.length, 300);
                if (n < 0) break;
                if (n > 0) bo.write(b, 0, n);
                if (System.currentTimeMillis() > end) break;
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8).replace("\r\n", "\n");
        } finally {
            s.close();
        }
    }

    /** Ejecuta un comando corto sin esperar (toques, teclas). Se encolan en orden. */
    public void inputAsync(String cmd) {
        inputExec.execute(() -> {
            try {
                shell(cmd, 8000);
            } catch (Exception ignored) {
            }
        });
    }

    /** Ejecuta un comando y muestra un aviso con el resultado. */
    public void shellToast(String okText, String cmd) {
        connectExec.execute(() -> {
            try {
                String out = shell(cmd, 20000).trim();
                String msg = out.isEmpty() ? okText : okText + "\n" + (out.length() > 160 ? out.substring(0, 160) : out);
                toast(msg);
            } catch (Exception e) {
                toast("Error: " + e.getMessage());
            }
        });
    }

    public void toast(String s) {
        ui.post(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show());
    }

    public void showMessage(String title, String msg) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("Aceptar", null).show();
    }

    public interface TextCallback {
        void onText(String s);
    }

    public void askText(String title, String hint, boolean password, TextCallback cb) {
        EditText e = Ui.input(this, hint);
        if (password) e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        FrameLayout fl = new FrameLayout(this);
        fl.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0);
        fl.addView(e);
        new AlertDialog.Builder(this).setTitle(title).setView(fl)
                .setPositiveButton("Aceptar", (d, w) -> cb.onText(e.getText().toString()))
                .setNegativeButton("Cancelar", null).show();
    }

    public static String q(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }
}
