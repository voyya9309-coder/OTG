package cu.meneses.recuperamovil;

/** Separa un flujo H.264 (Annex B) en unidades NAL. */
public class NalSplitter {
    public interface Sink {
        void onNal(byte[] d, int off, int len);
    }

    private byte[] buf = new byte[1 << 20];
    private int len = 0;
    private int scan = 0;
    private int nalStart = -1;

    public void add(byte[] d, int n, Sink sink) {
        if (len + n > buf.length) {
            byte[] nb = new byte[Math.max(buf.length * 2, len + n)];
            System.arraycopy(buf, 0, nb, 0, len);
            buf = nb;
        }
        System.arraycopy(d, 0, buf, len, n);
        len += n;
        int i = Math.max(scan, 0);
        while (i + 2 < len) {
            if (buf[i] == 0 && buf[i + 1] == 0 && buf[i + 2] == 1) {
                if (nalStart >= 0) emit(nalStart, i, sink);
                nalStart = i + 3;
                i += 3;
            } else {
                i++;
            }
        }
        scan = Math.max(len - 2, 0);
        if (nalStart >= 0) {
            if (nalStart > 0) {
                System.arraycopy(buf, nalStart, buf, 0, len - nalStart);
                len -= nalStart;
                scan -= nalStart;
                if (scan < 0) scan = 0;
                nalStart = 0;
            }
        } else if (len > 3) {
            System.arraycopy(buf, len - 3, buf, 0, 3);
            len = 3;
            scan = 0;
        }
    }

    /** Si el flujo se detiene, entrega la ultima NAL pendiente para no retrasar la imagen. */
    public void flush(Sink sink) {
        if (nalStart >= 0 && len > nalStart + 1) {
            emit(nalStart, len, sink);
            len = 0;
            scan = 0;
            nalStart = -1;
        }
    }

    private void emit(int from, int to, Sink sink) {
        while (to > from && buf[to - 1] == 0) to--;
        if (to - from > 0) sink.onNal(buf, from, to - from);
    }
}
