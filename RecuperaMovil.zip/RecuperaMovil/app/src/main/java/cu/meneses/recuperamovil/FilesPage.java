package cu.meneses.recuperamovil;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Explorador de archivos del otro movil con copia en ambos sentidos. */
public class FilesPage extends Page {
    private final Transfers tr;
    private final LinearLayout root;
    private final TextView pathView;
    private final TextView destView;
    private final ListView list;
    private final TextView emptyView;
    private final List<SyncClient.Entry> entries = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private String curPath = "/sdcard";
    private boolean loadedOnce;
    private final SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);

    public FilesPage(MainActivity m, Transfers tr) {
        super(m);
        this.tr = tr;
        root = Ui.vbox(m);
        int p = Ui.dp(m, 12);
        root.setPadding(p, 0, p, p);

        LinearLayout bar = Ui.hbox(m);
        ImageView up = Ui.iconButton(m, R.drawable.ic_up);
        up.setOnClickListener(v -> goUp());
        bar.addView(up, Ui.lp(Ui.dp(m, 42), Ui.dp(m, 42)));
        pathView = Ui.text(m, curPath, 13, Ui.TEXT, true);
        pathView.setSingleLine(true);
        pathView.setEllipsize(android.text.TextUtils.TruncateAt.START);
        LinearLayout.LayoutParams pl = Ui.lpWeight(0, -2, 1);
        pl.leftMargin = Ui.dp(m, 10);
        pl.rightMargin = Ui.dp(m, 10);
        bar.addView(pathView, pl);
        ImageView rf = Ui.iconButton(m, R.drawable.ic_refresh);
        rf.setOnClickListener(v -> load(curPath));
        bar.addView(rf, Ui.lp(Ui.dp(m, 42), Ui.dp(m, 42)));
        root.addView(bar);

        HorizontalScrollView hs = new HorizontalScrollView(m);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = Ui.hbox(m);
        addChip(chips, "Interno", "/sdcard");
        addChip(chips, "Cámara", "/sdcard/DCIM");
        addChip(chips, "Imágenes", "/sdcard/Pictures");
        addChip(chips, "Descargas", "/sdcard/Download");
        addChip(chips, "Documentos", "/sdcard/Documents");
        addChip(chips, "WhatsApp", "/sdcard/Android/media/com.whatsapp/WhatsApp");
        addChip(chips, "Raíz", "/");
        hs.addView(chips);
        LinearLayout.LayoutParams hl = Ui.lp(-1, -2);
        hl.topMargin = Ui.dp(m, 8);
        root.addView(hs, hl);

        FrameLayout listBox = new FrameLayout(m);
        list = new ListView(m);
        list.setDivider(null);
        list.setAdapter(adapter);
        list.setBackground(Ui.roundStroke(m, Ui.SURFACE, Ui.LINE, 12));
        list.setOnItemClickListener((parent, v, pos, id) -> {
            SyncClient.Entry e = entries.get(pos);
            if (e.isDir() || e.isLink()) load(Transfers.join(curPath, e.name));
            else toggle(e);
        });
        list.setOnItemLongClickListener((parent, v, pos, id) -> {
            toggle(entries.get(pos));
            return true;
        });
        listBox.addView(list, new FrameLayout.LayoutParams(-1, -1));
        emptyView = Ui.text(m, "Conecte el otro móvil para ver sus archivos", 14, Ui.MUTED, false);
        emptyView.setGravity(Gravity.CENTER);
        listBox.addView(emptyView, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        LinearLayout.LayoutParams ll = Ui.lpWeight(-1, 0, 1);
        ll.topMargin = Ui.dp(m, 8);
        root.addView(listBox, ll);

        destView = Ui.text(m, "", 12, Ui.MUTED, false);
        destView.setSingleLine(true);
        destView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams dl = Ui.lp(-1, -2);
        dl.topMargin = Ui.dp(m, 8);
        root.addView(destView, dl);
        refreshDestLabel();

        LinearLayout row1 = Ui.hbox(m);
        LinearLayout bDest = Ui.button(m, "Destino", R.drawable.ic_folder, false);
        bDest.setOnClickListener(v -> tr.chooseDest());
        LinearLayout bAll = Ui.button(m, "Marcar todo", R.drawable.ic_check, false);
        bAll.setOnClickListener(v -> selectAll());
        row1.addView(bDest, Ui.lpWeight(0, -2, 1));
        LinearLayout.LayoutParams al = Ui.lpWeight(0, -2, 1);
        al.leftMargin = Ui.dp(m, 8);
        row1.addView(bAll, al);
        LinearLayout.LayoutParams r1 = Ui.lp(-1, -2);
        r1.topMargin = Ui.dp(m, 8);
        root.addView(row1, r1);

        LinearLayout row2 = Ui.hbox(m);
        LinearLayout bPull = Ui.button(m, "Copiar a mi móvil", R.drawable.ic_download, true);
        bPull.setOnClickListener(v -> pull());
        LinearLayout bPush = Ui.button(m, "Enviar al otro", R.drawable.ic_upload, false);
        bPush.setOnClickListener(v -> push());
        row2.addView(bPull, Ui.lpWeight(0, -2, 1));
        LinearLayout.LayoutParams pu = Ui.lpWeight(0, -2, 1);
        pu.leftMargin = Ui.dp(m, 8);
        row2.addView(bPush, pu);
        LinearLayout.LayoutParams r2 = Ui.lp(-1, -2);
        r2.topMargin = Ui.dp(m, 8);
        root.addView(row2, r2);
    }

    private void addChip(LinearLayout chips, String label, String path) {
        LinearLayout b = Ui.button(main, label, 0, false);
        b.setOnClickListener(v -> {
            if (path.contains("com.whatsapp")) loadWhatsapp();
            else load(path);
        });
        LinearLayout.LayoutParams lp = Ui.lp(-2, -2);
        lp.rightMargin = Ui.dp(main, 8);
        chips.addView(b, lp);
    }

    public void refreshDestLabel() {
        destView.setText("Se guarda en este móvil: " + tr.destName());
    }

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShown() {
        if (main.connected() && !loadedOnce) load(curPath, "/storage/emulated/0");
    }

    @Override
    public void onConnectionChanged(boolean connected) {
        main.ui.post(() -> {
            loadedOnce = false;
            entries.clear();
            selected.clear();
            adapter.notifyDataSetChanged();
            emptyView.setText("Conecte el otro móvil para ver sus archivos");
            emptyView.setVisibility(View.VISIBLE);
        });
    }

    public boolean goUp() {
        if (!main.connected() || curPath.equals("/")) return false;
        int i = curPath.lastIndexOf('/');
        String parent = i <= 0 ? "/" : curPath.substring(0, i);
        if (curPath.equals("/sdcard")) parent = "/";
        load(parent);
        return true;
    }

    private void loadWhatsapp() {
        load("/sdcard/Android/media/com.whatsapp/WhatsApp", "/sdcard/WhatsApp");
    }

    private void load(String path) {
        load(path, null);
    }

    private void load(String path, String fallback) {
        if (!main.connected()) {
            main.toast("No hay móvil conectado");
            return;
        }
        emptyView.setText("Cargando...");
        emptyView.setVisibility(View.VISIBLE);
        main.jobs.execute(() -> {
            AdbConnection c = main.adb();
            if (c == null) return;
            SyncClient sc = null;
            try {
                sc = new SyncClient(c);
                String use = path;
                List<SyncClient.Entry> res;
                try {
                    res = sc.list(use);
                } catch (SyncClient.RemoteFailure rf) {
                    res = new ArrayList<>();
                }
                if (res.isEmpty() && fallback != null) {
                    use = fallback;
                    res = sc.list(use);
                }
                final List<SyncClient.Entry> shownList = new ArrayList<>();
                for (SyncClient.Entry e : res) {
                    if (e.name.equals(".") || e.name.equals("..")) continue;
                    shownList.add(e);
                }
                Collections.sort(shownList, (x, y) -> {
                    boolean dx = x.isDir() || x.isLink();
                    boolean dy = y.isDir() || y.isLink();
                    if (dx != dy) return dx ? -1 : 1;
                    return x.name.compareToIgnoreCase(y.name);
                });
                final String finalPath = use;
                main.ui.post(() -> {
                    curPath = finalPath;
                    loadedOnce = true;
                    pathView.setText(curPath);
                    entries.clear();
                    entries.addAll(shownList);
                    selected.clear();
                    adapter.notifyDataSetChanged();
                    list.setSelection(0);
                    emptyView.setText("Carpeta vacía o sin permiso de lectura");
                    emptyView.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
                });
            } catch (Exception e) {
                main.toast("No se pudo abrir la carpeta: " + e.getMessage());
                main.ui.post(() -> emptyView.setText("No se pudo leer la carpeta"));
            } finally {
                if (sc != null) sc.close();
            }
        });
    }

    private void toggle(SyncClient.Entry e) {
        if (!selected.remove(e.name)) selected.add(e.name);
        adapter.notifyDataSetChanged();
    }

    private void selectAll() {
        if (selected.size() == entries.size()) selected.clear();
        else for (SyncClient.Entry e : entries) selected.add(e.name);
        adapter.notifyDataSetChanged();
    }

    private void pull() {
        if (!main.connected()) {
            main.toast("No hay móvil conectado");
            return;
        }
        final List<SyncClient.Entry> items = new ArrayList<>();
        for (SyncClient.Entry e : entries) if (selected.contains(e.name)) items.add(e);
        if (!items.isEmpty()) {
            tr.pull(items, curPath);
            return;
        }
        new AlertDialog.Builder(main).setTitle("Copiar carpeta")
                .setMessage("No hay nada marcado. ¿Copiar toda la carpeta actual?\n" + curPath)
                .setPositiveButton("Copiar", (d, w) -> {
                    int i = curPath.lastIndexOf('/');
                    List<String> one = new ArrayList<>();
                    one.add(curPath);
                    if (curPath.equals("/")) one.set(0, "/sdcard");
                    tr.pullPaths("Copiando a este móvil", one);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void push() {
        if (!main.connected()) {
            main.toast("No hay móvil conectado");
            return;
        }
        final String target = curPath;
        new AlertDialog.Builder(main).setTitle("Enviar a " + target)
                .setItems(new String[]{"Archivos de este móvil", "Una carpeta de este móvil"}, (d, which) -> {
                    if (which == 0) tr.pickFilesToSend(target);
                    else tr.pickFolderToSend(target);
                }).show();
    }

    private final BaseAdapter adapter = new BaseAdapter() {
        @Override
        public int getCount() {
            return entries.size();
        }

        @Override
        public Object getItem(int i) {
            return entries.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout row;
            if (convert == null) {
                row = Ui.hbox(main);
                int ph = Ui.dp(main, 12);
                row.setPadding(ph, Ui.dp(main, 10), ph, Ui.dp(main, 10));
                ImageView ic = new ImageView(main);
                row.addView(ic, Ui.lp(Ui.dp(main, 26), Ui.dp(main, 26)));
                LinearLayout col = Ui.vbox(main);
                TextView name = Ui.text(main, "", 14, Ui.TEXT, false);
                name.setSingleLine(true);
                name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                TextView sub = Ui.text(main, "", 11, Ui.MUTED, false);
                sub.setSingleLine(true);
                col.addView(name);
                col.addView(sub);
                LinearLayout.LayoutParams cl = Ui.lpWeight(0, -2, 1);
                cl.leftMargin = Ui.dp(main, 12);
                row.addView(col, cl);
                ImageView ck = new ImageView(main);
                ck.setImageResource(R.drawable.ic_check);
                ck.setColorFilter(Ui.ACCENT);
                row.addView(ck, Ui.lp(Ui.dp(main, 22), Ui.dp(main, 22)));
                convert = row;
            }
            row = (LinearLayout) convert;
            SyncClient.Entry e = entries.get(pos);
            ImageView ic = (ImageView) row.getChildAt(0);
            LinearLayout col = (LinearLayout) row.getChildAt(1);
            ImageView ck = (ImageView) row.getChildAt(2);
            boolean dir = e.isDir() || e.isLink();
            ic.setImageResource(dir ? R.drawable.ic_folder : R.drawable.ic_file);
            ic.setColorFilter(dir ? Ui.ACCENT : Ui.MUTED);
            ((TextView) col.getChildAt(0)).setText(e.name);
            String sub = dir ? "Carpeta" : Transfers.human(e.size);
            if (e.mtime > 0) sub += "   " + fmt.format(new Date(e.mtime * 1000L));
            ((TextView) col.getChildAt(1)).setText(sub);
            boolean sel = selected.contains(e.name);
            ck.setVisibility(sel ? View.VISIBLE : View.INVISIBLE);
            row.setBackgroundColor(sel ? 0x3322C3A6 : 0x00000000);
            return convert;
        }
    };
}
