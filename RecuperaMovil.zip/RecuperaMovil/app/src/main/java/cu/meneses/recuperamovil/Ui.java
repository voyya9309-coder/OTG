package cu.meneses.recuperamovil;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Utilidades de interfaz: colores y componentes con estilo propio. */
public final class Ui {
    public static final int BG = 0xFF0E1620;
    public static final int SURFACE = 0xFF16222E;
    public static final int SURFACE2 = 0xFF1F2F3F;
    public static final int LINE = 0xFF2A3C4D;
    public static final int ACCENT = 0xFF22C3A6;
    public static final int ACCENT_DARK = 0xFF138F7A;
    public static final int TEXT = 0xFFE8EEF4;
    public static final int MUTED = 0xFF8FA3B5;
    public static final int DANGER = 0xFFEF6A6A;
    public static final int OK = 0xFF4ADE80;

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable round(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable roundStroke(Context c, int color, int stroke, float radiusDp) {
        GradientDrawable g = round(c, color, radiusDp);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    public static Drawable ripple(Context c, Drawable base) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), base, null);
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static ImageView icon(Context c, int res, int tint, float sizeDp) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(tint);
        int s = dp(c, sizeDp);
        v.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return v;
    }

    public static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    public static LinearLayout.LayoutParams lpWeight(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    public static void margins(View v, Context c, int l, int t, int r, int b) {
        ViewGroup.LayoutParams p = v.getLayoutParams();
        if (p instanceof ViewGroup.MarginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) p).setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
            v.setLayoutParams(p);
        }
    }

    /** Tarjeta con fondo redondeado. */
    public static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(roundStroke(c, SURFACE, LINE, 14));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        return l;
    }

    /** Boton con icono opcional. primary = relleno de acento. */
    public static LinearLayout button(Context c, String label, int iconRes, boolean primary) {
        LinearLayout b = hbox(c);
        b.setGravity(Gravity.CENTER);
        int fill = primary ? ACCENT : SURFACE2;
        int fg = primary ? 0xFF06201B : TEXT;
        b.setBackground(ripple(c, round(c, fill, 12)));
        int ph = dp(c, 14);
        int pv = dp(c, 11);
        b.setPadding(ph, pv, ph, pv);
        b.setClickable(true);
        b.setFocusable(true);
        if (iconRes != 0) {
            ImageView iv = icon(c, iconRes, fg, 20);
            ((LinearLayout.LayoutParams) iv.getLayoutParams()).rightMargin = dp(c, 8);
            b.addView(iv);
        }
        TextView t = text(c, label, 14, fg, true);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        b.addView(t);
        return b;
    }

    public static void setButtonLabel(LinearLayout button, String label) {
        View v = button.getChildAt(button.getChildCount() - 1);
        if (v instanceof TextView) ((TextView) v).setText(label);
    }

    /** Boton vertical compacto: icono arriba, texto abajo. */
    public static LinearLayout toolButton(Context c, int iconRes, String label) {
        LinearLayout b = vbox(c);
        b.setGravity(Gravity.CENTER);
        b.setBackground(ripple(c, round(c, SURFACE2, 12)));
        int p = dp(c, 8);
        b.setPadding(p, p, p, p);
        b.setClickable(true);
        b.setFocusable(true);
        ImageView iv = icon(c, iconRes, TEXT, 22);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22)));
        b.addView(iv);
        TextView t = text(c, label, 11, MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        LinearLayout.LayoutParams tp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(c, 4);
        b.addView(t, tp);
        b.setMinimumWidth(dp(c, 68));
        return b;
    }

    public static ImageView iconButton(Context c, int res) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(TEXT);
        int p = dp(c, 10);
        v.setPadding(p, p, p, p);
        v.setBackground(ripple(c, round(c, SURFACE2, 12)));
        v.setClickable(true);
        v.setFocusable(true);
        return v;
    }

    public static EditText input(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setBackground(roundStroke(c, SURFACE, LINE, 12));
        int ph = dp(c, 12);
        e.setPadding(ph, dp(c, 10), ph, dp(c, 10));
        return e;
    }

    public static TextView sectionTitle(Context c, String s) {
        TextView t = text(c, s, 13, ACCENT, true);
        t.setLetterSpacing(0.06f);
        return t;
    }
}
