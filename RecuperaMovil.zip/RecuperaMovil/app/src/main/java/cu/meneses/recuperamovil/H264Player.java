package cu.meneses.recuperamovil;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.view.Surface;

import java.io.IOException;
import java.nio.ByteBuffer;

/** Decodifica el video H.264 del otro movil directamente sobre una superficie. */
public class H264Player {
    public interface SizeListener {
        void onVideoSize(int w, int h);
    }

    private final SizeListener sizeListener;
    private MediaCodec codec;
    private Thread drainThread;
    private volatile boolean running;
    private long pts = 0;

    public H264Player(SizeListener l) {
        this.sizeListener = l;
    }

    public synchronized void start(Surface surface, int w, int h) throws IOException {
        stop();
        MediaFormat f = MediaFormat.createVideoFormat("video/avc", w, h);
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 21);
        try {
            f.setInteger("low-latency", 1);
        } catch (Throwable ignored) {
        }
        MediaCodec c = MediaCodec.createDecoderByType("video/avc");
        c.configure(f, surface, null, 0);
        c.start();
        codec = c;
        running = true;
        pts = 0;
        drainThread = new Thread(() -> drain(c), "h264-drain");
        drainThread.setDaemon(true);
        drainThread.start();
    }

    private void drain(MediaCodec c) {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (running) {
            try {
                int i = c.dequeueOutputBuffer(info, 10000);
                if (i >= 0) {
                    c.releaseOutputBuffer(i, true);
                } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = c.getOutputFormat();
                    int w = of.getInteger(MediaFormat.KEY_WIDTH);
                    int h = of.getInteger(MediaFormat.KEY_HEIGHT);
                    if (of.containsKey("crop-right") && of.containsKey("crop-left")
                            && of.containsKey("crop-bottom") && of.containsKey("crop-top")) {
                        w = of.getInteger("crop-right") - of.getInteger("crop-left") + 1;
                        h = of.getInteger("crop-bottom") - of.getInteger("crop-top") + 1;
                    }
                    if (sizeListener != null) sizeListener.onVideoSize(w, h);
                }
            } catch (Exception e) {
                break;
            }
        }
    }

    public boolean feed(byte[] data, int len, boolean config, boolean key) {
        MediaCodec c = codec;
        if (c == null) return false;
        try {
            int idx = c.dequeueInputBuffer(50000);
            if (idx < 0) return false;
            ByteBuffer ib = c.getInputBuffer(idx);
            if (ib == null) return false;
            ib.clear();
            if (len > ib.capacity()) len = ib.capacity();
            ib.put(data, 0, len);
            int flags = (config ? MediaCodec.BUFFER_FLAG_CODEC_CONFIG : 0) | (key ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0);
            c.queueInputBuffer(idx, 0, len, pts, flags);
            pts += 33333;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public synchronized void stop() {
        running = false;
        MediaCodec c = codec;
        codec = null;
        Thread t = drainThread;
        drainThread = null;
        if (t != null) {
            try {
                t.join(500);
            } catch (InterruptedException ignored) {
            }
        }
        if (c != null) {
            try {
                c.stop();
            } catch (Exception ignored) {
            }
            try {
                c.release();
            } catch (Exception ignored) {
            }
        }
    }
}
