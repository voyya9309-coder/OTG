package cu.meneses.recuperamovil;

import android.graphics.Typeface;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Consola de comandos para el otro movil. */
public class TerminalPage extends Page {
    private final LinearLayout root;
    private final TextView out;
    private final ScrollView scroll;
    private final EditText input;

    public TerminalPage(MainActivity m) {
        super(m);
        root = Ui.vbox(m);
        int p = Ui.dp(m, 12);
        root.setPadding(p, 0, p, p);
        scroll = new ScrollView(m);
        scroll.setBackground(Ui.roundStroke(m, 0xFF080D12, Ui.LINE, 12));
        out = Ui.text(m, "Escriba un comando del otro móvil, por ejemplo: pm list packages", 12, Ui.MUTED, false);
        out.setTypeface(Typeface.MONOSPACE);
        out.setTextIsSelectable(true);
        out.setPadding(p, p, p, p);
        scroll.addView(out);
        root.addView(scroll, Ui.lpWeight(-1, 0, 1));

        LinearLayout row = Ui.hbox(m);
        input = Ui.input(m, "Comando");
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setOnEditorActionListener((v, a, e) -> {
            run();
            return true;
        });
        row.addView(input, Ui.lpWeight(0, -2, 1));
        LinearLayout go = Ui.button(m, "Ejecutar", R.drawable.ic_terminal, true);
        go.setOnClickListener(v -> run());
        LinearLayout.LayoutParams gl = Ui.lp(-2, -2);
        gl.leftMargin = Ui.dp(m, 8);
        row.addView(go, gl);
        LinearLayout.LayoutParams rl = Ui.lp(-1, -2);
        rl.topMargin = Ui.dp(m, 8);
        root.addView(row, rl);
    }

    private void run() {
        String cmd = input.getText().toString().trim();
        if (cmd.isEmpty()) return;
        if (!main.connected()) {
            main.toast("No hay móvil conectado");
            return;
        }
        input.setText("");
        append("$ " + cmd + "\n");
        main.jobs.execute(() -> {
            try {
                String r = main.shell(cmd, 60000);
                append(r.isEmpty() ? "(sin salida)\n" : r + (r.endsWith("\n") ? "" : "\n"));
            } catch (Exception e) {
                append("Error: " + e.getMessage() + "\n");
            }
        });
    }

    private void append(String s) {
        main.ui.post(() -> {
            CharSequence cur = out.getText();
            String all = cur.toString().startsWith("Escriba un comando") ? "" : cur.toString();
            all += s;
            if (all.length() > 60000) all = all.substring(all.length() - 60000);
            out.setText(all);
            out.setTextColor(Ui.TEXT);
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    @Override
    public View view() {
        return root;
    }
}
