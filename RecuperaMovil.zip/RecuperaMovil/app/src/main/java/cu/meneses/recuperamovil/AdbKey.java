package cu.meneses.recuperamovil;

import android.content.Context;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/** Clave RSA propia para autenticarse ante el depurador USB del otro movil. */
public class AdbKey {
    private static final byte[] SHA1_PREFIX = {
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    };

    private final RSAPrivateKey priv;
    private final RSAPublicKey pub;

    public AdbKey(Context ctx) throws Exception {
        File fp = new File(ctx.getFilesDir(), "adbkey.priv");
        File fq = new File(ctx.getFilesDir(), "adbkey.pub");
        KeyFactory kf = KeyFactory.getInstance("RSA");
        RSAPrivateKey pr;
        RSAPublicKey pu;
        if (fp.exists() && fq.exists()) {
            pr = (RSAPrivateKey) kf.generatePrivate(new PKCS8EncodedKeySpec(readAll(fp)));
            pu = (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(readAll(fq)));
        } else {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            KeyPair kp = g.generateKeyPair();
            pr = (RSAPrivateKey) kp.getPrivate();
            pu = (RSAPublicKey) kp.getPublic();
            writeAll(fp, pr.getEncoded());
            writeAll(fq, pu.getEncoded());
        }
        priv = pr;
        pub = pu;
    }

    private static byte[] readAll(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toByteArray();
        }
    }

    private static void writeAll(File f, byte[] data) throws IOException {
        try (FileOutputStream out = new FileOutputStream(f)) {
            out.write(data);
        }
    }

    /** Firma el token de 20 bytes que envia el otro movil (RSA PKCS#1 v1.5 con prefijo SHA-1). */
    public byte[] sign(byte[] token) {
        byte[] data = new byte[SHA1_PREFIX.length + token.length];
        System.arraycopy(SHA1_PREFIX, 0, data, 0, SHA1_PREFIX.length);
        System.arraycopy(token, 0, data, SHA1_PREFIX.length, token.length);
        int k = 256;
        byte[] em = new byte[k];
        em[0] = 0;
        em[1] = 1;
        int psEnd = k - data.length - 1;
        for (int i = 2; i < psEnd; i++) em[i] = (byte) 0xff;
        em[psEnd] = 0;
        System.arraycopy(data, 0, em, k - data.length, data.length);
        BigInteger m = new BigInteger(1, em);
        BigInteger s = m.modPow(priv.getPrivateExponent(), priv.getModulus());
        return toFixed(s, k);
    }

    private static byte[] toFixed(BigInteger v, int len) {
        byte[] raw = v.toByteArray();
        byte[] out = new byte[len];
        if (raw.length > len) {
            System.arraycopy(raw, raw.length - len, out, 0, len);
        } else {
            System.arraycopy(raw, 0, out, len - raw.length, raw.length);
        }
        return out;
    }

    /** Clave publica en el formato propio de Android (mincrypt), en base64 y terminada en NUL. */
    public byte[] publicKeyBlob() {
        BigInteger n = pub.getModulus();
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        BigInteger mask = r32.subtract(BigInteger.ONE);
        int n0inv = r32.subtract(n.mod(r32).modInverse(r32)).intValue();
        BigInteger rr = BigInteger.ONE.shiftLeft(4096).mod(n);
        ByteBuffer bb = ByteBuffer.allocate(4 + 4 + 256 + 256 + 4).order(ByteOrder.LITTLE_ENDIAN);
        bb.putInt(64);
        bb.putInt(n0inv);
        for (int i = 0; i < 64; i++) bb.putInt(n.shiftRight(32 * i).and(mask).intValue());
        for (int i = 0; i < 64; i++) bb.putInt(rr.shiftRight(32 * i).and(mask).intValue());
        bb.putInt(pub.getPublicExponent().intValue());
        byte[] b64 = Base64.encode(bb.array(), Base64.NO_WRAP);
        byte[] tail = " recuperamovil@android\0".getBytes();
        byte[] out = new byte[b64.length + tail.length];
        System.arraycopy(b64, 0, out, 0, b64.length);
        System.arraycopy(tail, 0, out, b64.length, tail.length);
        return out;
    }
}
