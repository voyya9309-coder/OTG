package cu.meneses.recuperamovil;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Duplica la pantalla del otro movil y permite controlarla con toques. */
public class MirrorPage extends Page {
    private final LinearLayout root;
    private final FrameLayout container;
    private final SurfaceView surfaceView;
    private final TextView status;
    private final EditText textInput;
    private final LinearLayout qualityBtn;
    private final SharedPreferences prefs;

    private volatile boolean mirrorRun;
    private Thread mirrorThread;
    private volatile AdbConnection.AdbStream videoStream;
    private volatile android.view.Surface surface;
    private volatile int videoW, videoH;
    private boolean shown;

    private static final String[] QUALITY_NAMES = {"Baja", "Media", "Alta"};
    private static final int[] QUALITY_SIDE = {854, 1280, 1920};
    private static final int[] QUALITY_RATE = {2000000, 4000000, 8000000};
    private int quality;

    private float downX, downY;
    private long downT;

    public MirrorPage(MainActivity m) {
        super(m);
        prefs = m.getSharedPreferences("recupera", Context.MODE_PRIVATE);
        quality = prefs.getInt("quality", 1);

        root = Ui.vbox(m);
        container = new FrameLayout(m);
        container.setBackground(Ui.round(m, 0xFF05090D, 0));
        surfaceView = new SurfaceView(m);
        container.addView(surfaceView, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        status = Ui.text(m, "Conecte el otro móvil para ver su pantalla", 14, Ui.MUTED, false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(Ui.dp(m, 24), 0, Ui.dp(m, 24), 0);
        container.addView(status, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        root.addView(container, Ui.lpWeight(-1, 0, 1));
        container.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> fitSurface());

        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder h) {
                surface = h.getSurface();
                if (shown && main.connected()) startMirror();
            }

            @Override
            public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder h) {
                stopMirror();
                surface = null;
            }
        });
        surfaceView.setOnTouchListener((v, ev) -> {
            onTouch(v, ev);
            return true;
        });

        // barra de herramientas
        HorizontalScrollView hs = new HorizontalScrollView(m);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = Ui.hbox(m);
        int p = Ui.dp(m, 8);
        tools.setPadding(p, p, p, 0);
        addTool(tools, R.drawable.ic_back, "Atrás", () -> key(4));
        addTool(tools, R.drawable.ic_home, "Inicio", () -> key(3));
        addTool(tools, R.drawable.ic_recents, "Recientes", () -> key(187));
        addTool(tools, R.drawable.ic_sun, "Encender", () -> key(224));
        addTool(tools, R.drawable.ic_lock, "Desbloq.", this::unlockSwipe);
        addTool(tools, R.drawable.ic_power, "Apagar", () -> key(223));
        addTool(tools, R.drawable.ic_vol_up, "Vol +", () -> key(24));
        addTool(tools, R.drawable.ic_vol_down, "Vol -", () -> key(25));
        addTool(tools, R.drawable.ic_bell, "Avisos", () -> main.inputAsync("cmd statusbar expand-notifications || service call statusbar 1"));
        addTool(tools, R.drawable.ic_refresh, "Reiniciar", () -> {
            stopMirror();
            if (main.connected()) startMirror();
        });
        qualityBtn = Ui.toolButton(m, R.drawable.ic_screen, "Calidad: " + QUALITY_NAMES[quality]);
        qualityBtn.setOnClickListener(v -> {
            quality = (quality + 1) % 3;
            prefs.edit().putInt("quality", quality).apply();
            ((TextView) qualityBtn.getChildAt(1)).setText("Calidad: " + QUALITY_NAMES[quality]);
            stopMirror();
            if (main.connected()) startMirror();
        });
        LinearLayout.LayoutParams ql = Ui.lp(-2, -2);
        ql.leftMargin = Ui.dp(m, 6);
        tools.addView(qualityBtn, ql);
        hs.addView(tools);
        root.addView(hs);

        // escribir texto
        LinearLayout row = Ui.hbox(m);
        row.setPadding(p, p, p, p);
        textInput = Ui.input(m, "Escribir en el otro móvil (sin tildes)");
        row.addView(textInput, Ui.lpWeight(0, -2, 1));
        LinearLayout send = Ui.button(m, "Enviar", 0, true);
        send.setOnClickListener(v -> sendText(false));
        LinearLayout enter = Ui.button(m, "Enter", 0, false);
        enter.setOnClickListener(v -> key(66));
        LinearLayout.LayoutParams sl = Ui.lp(-2, -2);
        sl.leftMargin = Ui.dp(m, 8);
        row.addView(send, sl);
        row.addView(enter, sl);
        root.addView(row);
    }

    private void addTool(LinearLayout tools, int icon, String label, Runnable r) {
        LinearLayout b = Ui.toolButton(main, icon, label);
        b.setOnClickListener(v -> {
            if (!main.connected()) {
                main.toast("No hay móvil conectado");
                return;
            }
            r.run();
        });
        LinearLayout.LayoutParams lp = Ui.lp(-2, -2);
        lp.leftMargin = Ui.dp(main, 6);
        tools.addView(b, lp);
    }

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShown() {
        shown = true;
        if (main.connected() && surface != null) startMirror();
        updateStatus();
    }

    @Override
    public void onHidden() {
        shown = false;
        stopMirror();
    }

    @Override
    public void onConnectionChanged(boolean connected) {
        main.ui.post(() -> {
            if (!connected) {
                stopMirror();
                videoW = 0;
                videoH = 0;
            } else if (shown && surface != null) {
                startMirror();
            }
            updateStatus();
        });
    }

    private void updateStatus() {
        if (!main.connected()) {
            status.setText("Conecte el otro móvil para ver su pantalla");
            status.setVisibility(View.VISIBLE);
        } else if (videoW == 0) {
            status.setText("Iniciando la pantalla del otro móvil...");
            status.setVisibility(View.VISIBLE);
        } else {
            status.setVisibility(View.GONE);
        }
    }

    // ---------------------------------------------------------------- tamano de la superficie

    private void fitSurface() {
        int cw = container.getWidth();
        int ch = container.getHeight();
        if (cw == 0 || ch == 0) return;
        float aspect;
        if (videoW > 0 && videoH > 0) aspect = (float) videoW / videoH;
        else if (main.physW() > 0) aspect = (float) main.physW() / main.physH();
        else aspect = 9f / 16f;
        int w = cw;
        int h = Math.round(cw / aspect);
        if (h > ch) {
            h = ch;
            w = Math.round(ch * aspect);
        }
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) surfaceView.getLayoutParams();
        if (lp.width != w || lp.height != h) {
            lp.width = w;
            lp.height = h;
            lp.gravity = Gravity.CENTER;
            surfaceView.setLayoutParams(lp);
        }
    }

    // ---------------------------------------------------------------- entrada

    private void key(int code) {
        main.inputAsync("input keyevent " + code);
    }

    private void unlockSwipe() {
        int[] d = logicalSize();
        int x = d[0] / 2;
        main.inputAsync("input keyevent 224");
        main.inputAsync("input swipe " + x + " " + (int) (d[1] * 0.85) + " " + x + " " + (int) (d[1] * 0.2) + " 300");
    }

    private void sendText(boolean enter) {
        String t = textInput.getText().toString();
        if (t.isEmpty() || !main.connected()) return;
        main.inputAsync("input text " + MainActivity.q(t.replace(" ", "%s")));
        textInput.setText("");
    }

    private int[] logicalSize() {
        int pw = main.physW() > 0 ? main.physW() : 1080;
        int ph = main.physH() > 0 ? main.physH() : 1920;
        int mx = Math.max(pw, ph);
        int mn = Math.min(pw, ph);
        if (videoW > videoH && videoH > 0) return new int[]{mx, mn};
        return new int[]{mn, mx};
    }

    private int[] mapPoint(float x, float y, View v) {
        float nx = Math.max(0f, Math.min(1f, x / Math.max(1, v.getWidth())));
        float ny = Math.max(0f, Math.min(1f, y / Math.max(1, v.getHeight())));
        int[] d = logicalSize();
        return new int[]{(int) (nx * (d[0] - 1)), (int) (ny * (d[1] - 1))};
    }

    private void onTouch(View v, MotionEvent ev) {
        if (!main.connected()) return;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = ev.getX();
                downY = ev.getY();
                downT = ev.getEventTime();
                break;
            case MotionEvent.ACTION_UP: {
                float dx = ev.getX() - downX;
                float dy = ev.getY() - downY;
                long dt = ev.getEventTime() - downT;
                float dist = (float) Math.hypot(dx, dy) / main.getResources().getDisplayMetrics().density;
                int[] a = mapPoint(downX, downY, v);
                int[] b = mapPoint(ev.getX(), ev.getY(), v);
                if (dist < 10) {
                    if (dt > 600) main.inputAsync("input swipe " + a[0] + " " + a[1] + " " + a[0] + " " + a[1] + " " + dt);
                    else main.inputAsync("input tap " + a[0] + " " + a[1]);
                } else {
                    long dur = Math.max(80, Math.min(1500, dt));
                    main.inputAsync("input swipe " + a[0] + " " + a[1] + " " + b[0] + " " + b[1] + " " + dur);
                }
                break;
            }
            default:
                break;
        }
    }

    // ---------------------------------------------------------------- espejo

    private synchronized void startMirror() {
        if (mirrorThread != null && mirrorThread.isAlive()) return;
        final android.view.Surface s = surface;
        if (s == null || !s.isValid()) return;
        mirrorRun = true;
        mirrorThread = new Thread(() -> mirrorLoop(s), "mirror");
        mirrorThread.setDaemon(true);
        mirrorThread.start();
    }

    private void stopMirror() {
        mirrorRun = false;
        AdbConnection.AdbStream vs = videoStream;
        if (vs != null) vs.close();
        Thread t = mirrorThread;
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(2500);
            } catch (InterruptedException ignored) {
            }
        }
        mirrorThread = null;
        if (main.connected()) main.inputAsync("pkill -2 screenrecord || killall -2 screenrecord");
    }

    private void setStatus(String s, boolean visible) {
        main.ui.post(() -> {
            status.setText(s);
            status.setVisibility(visible ? View.VISIBLE : View.GONE);
        });
    }

    private void mirrorLoop(android.view.Surface s) {
        H264Player player = new H264Player((w, h) -> main.ui.post(() -> {
            videoW = w;
            videoH = h;
            fitSurface();
            status.setVisibility(View.GONE);
        }));
        try {
            while (mirrorRun) {
                AdbConnection c = main.adb();
                if (c == null) break;
                int[] size = mirrorSize();
                try {
                    player.start(s, size[0], size[1]);
                } catch (Exception e) {
                    setStatus("Este móvil no pudo iniciar el decodificador de video", true);
                    break;
                }
                String cmd = "screenrecord --output-format=h264 --size " + size[0] + "x" + size[1]
                        + " --bit-rate " + QUALITY_RATE[quality] + " -";
                boolean gotFrames = false;
                String junk = "";
                try {
                    AdbConnection.AdbStream vs = c.openCommand(cmd);
                    videoStream = vs;
                    StreamResult r = readVideo(vs, c.usesPty(), player);
                    gotFrames = r.frames;
                    junk = r.head;
                    vs.close();
                } catch (Exception e) {
                    if (mirrorRun) junk = e.getMessage() == null ? "" : e.getMessage();
                }
                videoStream = null;
                player.stop();
                if (!mirrorRun) break;
                if (!gotFrames) {
                    String msg = junk.trim();
                    if (msg.length() > 200) msg = msg.substring(0, 200);
                    setStatus("No llega imagen del otro móvil. " + msg
                            + "\nCompruebe que su pantalla está encendida (botón Encender).", true);
                    sleep(2500);
                } else {
                    sleep(300);
                }
            }
        } finally {
            player.stop();
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private int[] mirrorSize() {
        int pw = main.physW() > 0 ? main.physW() : 1080;
        int ph = main.physH() > 0 ? main.physH() : 1920;
        int rot = 0;
        try {
            String d = main.shell("dumpsys input", 8000);
            Matcher m = Pattern.compile("SurfaceOrientation:\\s*(\\d)").matcher(d);
            if (m.find()) {
                rot = Integer.parseInt(m.group(1));
            } else {
                Matcher m2 = Pattern.compile("orientation=(\\d)").matcher(d);
                if (m2.find()) rot = Integer.parseInt(m2.group(1));
            }
        } catch (Exception ignored) {
        }
        int w = pw;
        int h = ph;
        boolean landscape = (rot == 1 || rot == 3);
        if (landscape) {
            w = Math.max(pw, ph);
            h = Math.min(pw, ph);
        } else {
            w = Math.min(pw, ph);
            h = Math.max(pw, ph);
        }
        float scale = Math.min(1f, (float) QUALITY_SIDE[quality] / Math.max(w, h));
        w = Math.max(16, Math.round(w * scale / 2f) * 2);
        h = Math.max(16, Math.round(h * scale / 2f) * 2);
        return new int[]{w, h};
    }

    private static class StreamResult {
        boolean frames;
        String head = "";
    }

    private StreamResult readVideo(AdbConnection.AdbStream vs, boolean pty, H264Player player) throws Exception {
        final StreamResult res = new StreamResult();
        final byte[] startCode = {0, 0, 0, 1};
        final byte[][] sps = new byte[1][];
        NalSplitter splitter = new NalSplitter();
        NalSplitter.Sink sink = (d, off, len) -> {
            int type = d[off] & 0x1f;
            if (type == 7) {
                sps[0] = new byte[len];
                System.arraycopy(d, off, sps[0], 0, len);
            } else if (type == 8) {
                if (sps[0] != null) {
                    byte[] merged = new byte[4 + sps[0].length + 4 + len];
                    System.arraycopy(startCode, 0, merged, 0, 4);
                    System.arraycopy(sps[0], 0, merged, 4, sps[0].length);
                    System.arraycopy(startCode, 0, merged, 4 + sps[0].length, 4);
                    System.arraycopy(d, off, merged, 8 + sps[0].length, len);
                    player.feed(merged, merged.length, true, false);
                }
            } else if (type == 5 || type == 1) {
                byte[] f = new byte[4 + len];
                System.arraycopy(startCode, 0, f, 0, 4);
                System.arraycopy(d, off, f, 4, len);
                player.feed(f, f.length, false, type == 5);
                res.frames = true;
            }
        };
        ByteArrayOutputStream head = new ByteArrayOutputStream();
        byte[] buf = new byte[32768];
        boolean[] pendingCr = new boolean[1];
        while (mirrorRun) {
            int n = vs.read(buf, 0, buf.length, 40);
            if (n < 0) break;
            if (n == 0) {
                splitter.flush(sink);
                continue;
            }
            if (pty) n = unCrlf(buf, n, pendingCr);
            if (!res.frames && head.size() < 300) head.write(buf, 0, Math.min(n, 300 - head.size()));
            splitter.add(buf, n, sink);
        }
        String h = new String(head.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
        StringBuilder clean = new StringBuilder();
        for (char ch : h.toCharArray()) if (ch >= 32 && ch < 127 || ch == '\n') clean.append(ch);
        res.head = clean.toString();
        return res;
    }

    /** Deshace la conversion \n -> \r\n de los moviles viejos sin exec:. */
    private static int unCrlf(byte[] b, int n, boolean[] pending) {
        int o = 0;
        for (int i = 0; i < n; i++) {
            byte x = b[i];
            if (pending[0]) {
                pending[0] = false;
                if (x == 0x0A) {
                    b[o++] = 0x0A;
                    continue;
                }
                b[o++] = 0x0D;
            }
            if (x == 0x0D) pending[0] = true;
            else b[o++] = x;
        }
        return o;
    }
}
