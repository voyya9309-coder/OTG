RECUPERA MOVIL
==============
App nativa de Android. Se instala en el movil que SI funciona. Con un cable OTG se
conecta al otro movil (el de la pantalla danada) y permite:

  - Ver y controlar su pantalla (duplicado de pantalla con toques, teclas y texto)
  - Explorar sus archivos y copiarlos a este movil, o enviar archivos desde este movil
  - Exportar contactos, SMS y registro de llamadas
  - Cambiar ajustes (Wi-Fi, datos, brillo, desbloqueo con PIN, etc.) y usar una terminal

REQUISITO: el otro movil debe tener la Depuracion USB activada y aceptar una vez el
aviso "Permitir depuracion USB" cuando se conecte por primera vez.

COMPILAR EN GITHUB
  1. Suba a la raiz del repositorio este zip (sin descomprimir).
  2. Suba build-apk.yml dentro de la carpeta .github/workflows/
  3. En Actions se compila solo. El APK queda en "Artifacts" (RecuperaMovil-apk).
