package com.otgrescue.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class ScreenView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    interface Listener {
        fun onTap(x: Int, y: Int)
        fun onSwipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int)
    }

    var bitmap: Bitmap? = null
        set(v) { field = v; invalidate() }
    var listener: Listener? = null

    private val dst = RectF()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.parseColor("#2DD4BF")
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8FA3BF"); textSize = 40f; textAlign = Paint.Align.CENTER
    }
    private var sx = 0f
    private var sy = 0f
    private var t0 = 0L

    override fun onDraw(c: Canvas) {
        val b = bitmap
        if (b == null) {
            c.drawText("Sin imagen del otro móvil", width / 2f, height / 2f, label)
            return
        }
        val scale = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val w = b.width * scale
        val h = b.height * scale
        val l = (width - w) / 2f
        val t = (height - h) / 2f
        dst.set(l, t, l + w, t + h)
        c.drawBitmap(b, null, dst, paint)
        c.drawRect(dst, border)
    }

    private fun mapX(x: Float): Int {
        val b = bitmap ?: return 0
        return (((x - dst.left) / dst.width()) * b.width).toInt().coerceIn(0, b.width - 1)
    }

    private fun mapY(y: Float): Int {
        val b = bitmap ?: return 0
        return (((y - dst.top) / dst.height()) * b.height).toInt().coerceIn(0, b.height - 1)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bitmap == null) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; t0 = System.currentTimeMillis() }
            MotionEvent.ACTION_UP -> {
                if (!dst.contains(sx, sy)) return true
                val dur = (System.currentTimeMillis() - t0).toInt()
                val dist = hypot(e.x - sx, e.y - sy)
                val slop = 18 * resources.displayMetrics.density
                if (dist < slop) {
                    if (dur > 500) listener?.onSwipe(mapX(sx), mapY(sy), mapX(sx), mapY(sy), dur)
                    else listener?.onTap(mapX(sx), mapY(sy))
                } else {
                    listener?.onSwipe(mapX(sx), mapY(sy), mapX(e.x), mapY(e.y), max(100, min(dur, 1500)))
                }
            }
        }
        return true
    }
}
