package com.otgrescue.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.format.Formatter
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val ACTION_PERM = "com.otgrescue.app.USB_PERMISSION"
    private lateinit var usb: UsbManager
    @Volatile private var adb: AdbConnection? = null
    private val io = Executors.newSingleThreadExecutor()
    private val work = Executors.newSingleThreadExecutor()
    @Volatile private var mirroring = false
    @Volatile private var screenVisible = true
    @Volatile private var busy = false

    private lateinit var tvStatus: TextView
    private lateinit var screenView: ScreenView
    private lateinit var panelScreen: View
    private lateinit var panelFiles: View
    private lateinit var panelTools: ScrollView
    private lateinit var tvPath: TextView
    private lateinit var tvOut: TextView
    private lateinit var listFiles: ListView

    private var currentPath = "/sdcard"
    private var entries: List<Entry> = emptyList()
    private val adapter = FileAdapter()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERM -> {
                    @Suppress("DEPRECATION")
                    val d = i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && d != null) startAdb(d)
                    else setStatus("Permiso USB denegado")
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    mirroring = false
                    adb = null
                    setStatus("Cable desconectado")
                }
            }
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) upload(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager

        tvStatus = findViewById(R.id.tvStatus)
        screenView = findViewById(R.id.screenView)
        panelScreen = findViewById(R.id.panelScreen)
        panelFiles = findViewById(R.id.panelFiles)
        panelTools = findViewById(R.id.panelTools)
        tvPath = findViewById(R.id.tvPath)
        tvOut = findViewById(R.id.tvOut)
        listFiles = findViewById(R.id.listFiles)
        listFiles.adapter = adapter

        val f = IntentFilter(ACTION_PERM)
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)

        findViewById<MaterialButton>(R.id.btnConnect).setOnClickListener { connect() }

        screenView.listener = object : ScreenView.Listener {
            override fun onTap(x: Int, y: Int) = shell("input tap $x $y")
            override fun onSwipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int) = shell("input swipe $x1 $y1 $x2 $y2 $ms")
        }
        findViewById<View>(R.id.btnBack).setOnClickListener { shell("input keyevent 4") }
        findViewById<View>(R.id.btnHome).setOnClickListener { shell("input keyevent 3") }
        findViewById<View>(R.id.btnRecents).setOnClickListener { shell("input keyevent 187") }
        findViewById<View>(R.id.btnPower).setOnClickListener { shell("input keyevent 26") }
        findViewById<View>(R.id.btnWake).setOnClickListener { shell("input keyevent 224") }
        val etText = findViewById<TextInputEditText>(R.id.etText)
        findViewById<View>(R.id.btnSendText).setOnClickListener {
            val t = etText.text?.toString().orEmpty()
            if (t.isNotEmpty()) { shell("input text " + quote(t)); etText.setText("") }
        }

        val nav = findViewById<BottomNavigationView>(R.id.nav)
        nav.setOnItemSelectedListener {
            screenVisible = it.itemId == R.id.navScreen
            panelScreen.visibility = if (screenVisible) View.VISIBLE else View.GONE
            panelFiles.visibility = if (it.itemId == R.id.navFiles) View.VISIBLE else View.GONE
            panelTools.visibility = if (it.itemId == R.id.navTools) View.VISIBLE else View.GONE
            if (it.itemId == R.id.navFiles && adb != null) loadDir(currentPath)
            true
        }

        val quick = mapOf(
            R.id.qRoot to "/sdcard", R.id.qDcim to "/sdcard/DCIM", R.id.qPics to "/sdcard/Pictures",
            R.id.qDown to "/sdcard/Download", R.id.qDocs to "/sdcard/Documents",
            R.id.qWa to "/sdcard/Android/media/com.whatsapp/WhatsApp"
        )
        for ((id, p) in quick) findViewById<View>(id).setOnClickListener { loadDir(p) }
        findViewById<View>(R.id.btnUp).setOnClickListener {
            loadDir(currentPath.substringBeforeLast('/').ifEmpty { "/" })
        }
        listFiles.setOnItemClickListener { _, _, p, _ ->
            val e = entries[p]
            if (e.isDir) loadDir(join(currentPath, e.name))
        }
        findViewById<View>(R.id.btnCopyDir).setOnClickListener {
            val name = currentPath.substringAfterLast('/').ifEmpty { "raiz" }
            copyEntries(currentPath, entries, name)
        }
        findViewById<View>(R.id.btnUpload).setOnClickListener { picker.launch(arrayOf("*/*")) }

        buildTools()
        screenView.bitmap = null
        connect()
    }

    override fun onDestroy() {
        super.onDestroy()
        mirroring = false
        unregisterReceiver(receiver)
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun setStatus(s: String) = runOnUiThread { tvStatus.text = s }
    private fun quote(s: String) = "'" + s.replace("'", "'\\''").replace(" ", "%s") + "'"
    private fun join(dir: String, name: String) = if (dir == "/") "/$name" else "$dir/$name"

    private fun shell(cmd: String) {
        val c = adb ?: run { toast("No hay conexión"); return }
        io.execute {
            try { c.run(cmd) } catch (e: Exception) { setStatus("Error: ${e.message}") }
        }
    }

    private fun connect() {
        val d = AdbConnection.findDevice(usb)
        if (d == null) {
            setStatus("No se detecta ningún móvil con depuración USB. Revisa el cable OTG.")
            return
        }
        if (usb.hasPermission(d)) { startAdb(d); return }
        val pi = PendingIntent.getBroadcast(
            this, 0, Intent(ACTION_PERM).setPackage(packageName), PendingIntent.FLAG_MUTABLE
        )
        usb.requestPermission(d, pi)
    }

    private fun startAdb(d: UsbDevice) {
        setStatus("Conectando...")
        work.execute {
            try {
                val c = AdbConnection(usb, d, AdbKey.load(this))
                c.connect { setStatus(it) }
                adb = c
                val model = c.runText("getprop ro.product.model")
                setStatus("Conectado: $model")
                runOnUiThread { startMirror(); loadDir(currentPath) }
            } catch (e: Exception) {
                setStatus("Error: ${e.message}")
            }
        }
    }

    private fun startMirror() {
        if (mirroring) return
        mirroring = true
        Thread {
            while (mirroring) {
                val c = adb ?: break
                if (!screenVisible) { Thread.sleep(300); continue }
                try {
                    val png = c.run("screencap -p")
                    val bmp = BitmapFactory.decodeByteArray(png, 0, png.size)
                    if (bmp != null) screenView.post { screenView.bitmap = bmp }
                } catch (e: Exception) {
                    setStatus("Conexión perdida: ${e.message}")
                    break
                }
                Thread.sleep(40)
            }
            mirroring = false
        }.start()
    }

    private fun loadDir(path: String) {
        val c = adb ?: return
        work.execute {
            try {
                val l = c.list(path).sortedWith(compareByDescending<Entry> { it.isDir }.thenBy { it.name.lowercase() })
                runOnUiThread {
                    currentPath = path
                    entries = l
                    tvPath.text = path
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                toast("No se puede abrir $path: ${e.message}")
            }
        }
    }

    private fun saveFile(remote: String, name: String, rel: String) {
        val v = ContentValues()
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        val base = "Download/OTGRescue" + if (rel.isEmpty()) "" else "/$rel"
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, base)
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            ?: throw IOException("No se pudo crear el archivo")
        contentResolver.openOutputStream(uri)!!.use { out -> adb!!.pull(remote, out) }
    }

    private fun copyEntries(dir: String, list: List<Entry>, rel: String) {
        val c = adb ?: return
        if (busy) { toast("Ya hay una copia en curso"); return }
        busy = true
        work.execute {
            var ok = 0
            var fail = 0
            fun walk(d: String, e: Entry, r: String) {
                val p = join(d, e.name)
                if (e.isDir) {
                    val sub = try { c.list(p) } catch (x: Exception) { fail++; return }
                    val nr = if (r.isEmpty()) e.name else "$r/${e.name}"
                    for (s in sub) walk(p, s, nr)
                } else {
                    try {
                        saveFile(p, e.name, r)
                        ok++
                        setStatus("Copiando... $ok archivos")
                    } catch (x: Exception) { fail++ }
                }
            }
            for (e in list) walk(dir, e, rel)
            busy = false
            setStatus("Copia terminada: $ok archivos, $fail errores. Carpeta Descargas/OTGRescue")
        }
    }

    private fun upload(uris: List<Uri>) {
        val c = adb ?: return toast("No hay conexión")
        val dest = currentPath
        work.execute {
            var ok = 0
            for (u in uris) {
                try {
                    var name = "archivo_${System.currentTimeMillis()}"
                    contentResolver.query(u, null, null, null, null)?.use { q ->
                        val i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (q.moveToFirst() && i >= 0) name = q.getString(i)
                    }
                    contentResolver.openInputStream(u)!!.use { c.push(join(dest, name), it) }
                    ok++
                    setStatus("Enviando... $ok de ${uris.size}")
                } catch (e: Exception) {
                    toast("Error al enviar: ${e.message}")
                }
            }
            setStatus("Enviados $ok de ${uris.size} archivos a $dest")
            runOnUiThread { loadDir(dest) }
        }
    }

    private fun runShow(cmd: String) {
        val c = adb ?: return toast("No hay conexión")
        tvOut.text = "Ejecutando..."
        work.execute {
            val r = try { c.runText(cmd) } catch (e: Exception) { "Error: ${e.message}" }
            runOnUiThread { tvOut.text = if (r.isEmpty()) "(sin salida)" else r }
        }
    }

    private fun buildTools() {
        val box = findViewById<LinearLayout>(R.id.quickList)
        val items = listOf(
            "Wi-Fi: activar" to "svc wifi enable", "Wi-Fi: desactivar" to "svc wifi disable",
            "Datos móviles: activar" to "svc data enable", "Datos móviles: desactivar" to "svc data disable",
            "Bluetooth: activar" to "svc bluetooth enable", "Bluetooth: desactivar" to "svc bluetooth disable",
            "Modo avión: activar" to "cmd connectivity airplane-mode enable",
            "Modo avión: desactivar" to "cmd connectivity airplane-mode disable",
            "Brillo máximo" to "settings put system screen_brightness 255",
            "Brillo medio" to "settings put system screen_brightness 128",
            "Pantalla encendida 30 min" to "settings put system screen_off_timeout 1800000",
            "No apagar pantalla al cargar" to "settings put global stay_on_while_plugged_in 3",
            "Rotación automática: activar" to "settings put system accelerometer_rotation 1",
            "Rotación automática: desactivar" to "settings put system accelerometer_rotation 0",
            "Abrir ajustes del sistema" to "am start -a android.settings.SETTINGS",
            "Abrir ajustes de Wi-Fi" to "am start -a android.settings.WIFI_SETTINGS"
        )
        val pad = (6 * resources.displayMetrics.density).toInt()
        for ((label, cmd) in items) {
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            b.text = label
            b.isAllCaps = false
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = pad
            b.layoutParams = lp
            b.setOnClickListener { runShow(cmd) }
            box.addView(b)
        }
        findViewById<View>(R.id.btnInfo).setOnClickListener {
            runShow(
                "echo Modelo: \$(getprop ro.product.model); echo Android: \$(getprop ro.build.version.release); " +
                    "dumpsys battery | grep -E 'level|status'; wm size; df -h /sdcard | tail -n 1"
            )
        }
        val etCmd = findViewById<TextInputEditText>(R.id.etCmd)
        findViewById<View>(R.id.btnRun).setOnClickListener {
            val t = etCmd.text?.toString().orEmpty().trim()
            if (t.isNotEmpty()) runShow(t)
        }
        val etPin = findViewById<TextInputEditText>(R.id.etPin)
        findViewById<View>(R.id.btnUnlock).setOnClickListener {
            val pin = etPin.text?.toString().orEmpty().filter { it.isDigit() }
            val c = adb ?: return@setOnClickListener toast("No hay conexión")
            work.execute {
                try {
                    c.run("input keyevent 224")
                    Thread.sleep(500)
                    val size = c.runText("wm size").substringAfterLast(' ').split('x')
                    val w = size.getOrNull(0)?.trim()?.toIntOrNull() ?: 1080
                    val h = size.getOrNull(1)?.trim()?.toIntOrNull() ?: 2400
                    c.run("input swipe ${w / 2} ${h * 4 / 5} ${w / 2} ${h / 5} 300")
                    Thread.sleep(600)
                    if (pin.isNotEmpty()) {
                        c.run("input text $pin")
                        c.run("input keyevent 66")
                    }
                    toast("Orden de desbloqueo enviada")
                } catch (e: Exception) {
                    toast("Error: ${e.message}")
                }
            }
        }
    }

    inner class FileAdapter : BaseAdapter() {
        override fun getCount() = entries.size
        override fun getItem(position: Int) = entries[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView ?: layoutInflater.inflate(R.layout.item_file, parent, false)
            val e = entries[position]
            row.findViewById<ImageView>(R.id.ivIcon).setImageResource(if (e.isDir) R.drawable.ic_folder_c else R.drawable.ic_file)
            row.findViewById<TextView>(R.id.tvName).text = e.name
            row.findViewById<TextView>(R.id.tvMeta).text =
                if (e.isDir) "Carpeta" else Formatter.formatFileSize(this@MainActivity, e.size)
            row.findViewById<ImageButton>(R.id.btnCopy).setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Copiar a este móvil")
                    .setMessage("${e.name} se guardará en Descargas/OTGRescue")
                    .setPositiveButton("Copiar") { _, _ -> copyEntries(currentPath, listOf(e), "") }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            return row
        }
    }
}
