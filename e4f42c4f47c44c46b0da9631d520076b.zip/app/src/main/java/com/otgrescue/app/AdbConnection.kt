package com.otgrescue.app

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPair

data class AdbMsg(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)
data class Entry(val name: String, val isDir: Boolean, val size: Long)

const val A_CNXN = 0x4e584e43
const val A_AUTH = 0x48545541
const val A_OPEN = 0x4e45504f
const val A_OKAY = 0x59414b4f
const val A_CLSE = 0x45534c43
const val A_WRTE = 0x45545257

class AdbStream(private val c: AdbConnection, val localId: Int, val remoteId: Int) {
    private val pending = ArrayList<ByteArray>()
    var closed = false

    private fun waitOk() {
        while (true) {
            val m = c.recv()
            if (m.cmd == A_OKAY) return
            if (m.cmd == A_WRTE) {
                pending.add(m.data)
                c.send(A_OKAY, localId, remoteId)
            } else if (m.cmd == A_CLSE) {
                closed = true
                throw IOException("El móvil cerró la conexión")
            }
        }
    }

    fun write(d: ByteArray) {
        var off = 0
        while (off < d.size) {
            val n = minOf(c.maxData, d.size - off)
            c.send(A_WRTE, localId, remoteId, d.copyOfRange(off, off + n))
            off += n
            waitOk()
        }
    }

    fun read(): ByteArray? {
        if (pending.isNotEmpty()) return pending.removeAt(0)
        if (closed) return null
        while (true) {
            val m = c.recv()
            if (m.cmd == A_WRTE) {
                c.send(A_OKAY, localId, remoteId)
                return m.data
            }
            if (m.cmd == A_CLSE) {
                closed = true
                return null
            }
        }
    }

    fun close() {
        if (closed) return
        try {
            c.send(A_CLSE, localId, remoteId)
            for (i in 0 until 20) {
                val m = c.recvOrNull(1000) ?: break
                if (m.cmd == A_CLSE) break
                if (m.cmd == A_WRTE) c.send(A_OKAY, localId, remoteId)
            }
        } catch (e: Exception) {
        }
        closed = true
    }
}

private class SyncIn(val s: AdbStream) {
    private var buf = ByteArray(0)
    private var pos = 0
    fun bytes(n: Int): ByteArray {
        while (buf.size - pos < n) {
            val d = s.read() ?: throw IOException("Conexión cerrada")
            buf = buf.copyOfRange(pos, buf.size) + d
            pos = 0
        }
        val r = buf.copyOfRange(pos, pos + n)
        pos += n
        return r
    }
    fun int(): Int = ByteBuffer.wrap(bytes(4)).order(ByteOrder.LITTLE_ENDIAN).int
}

class AdbConnection(
    private val mgr: UsbManager,
    private val dev: UsbDevice,
    private val key: KeyPair
) {
    companion object {
        fun adbInterface(d: UsbDevice): UsbInterface? {
            for (i in 0 until d.interfaceCount) {
                val itf = d.getInterface(i)
                if (itf.interfaceClass == 255 && itf.interfaceSubclass == 0x42 && itf.interfaceProtocol == 1) return itf
            }
            return null
        }

        fun findDevice(mgr: UsbManager): UsbDevice? =
            mgr.deviceList.values.firstOrNull { adbInterface(it) != null }
    }

    private lateinit var conn: UsbDeviceConnection
    private lateinit var inEp: UsbEndpoint
    private lateinit var outEp: UsbEndpoint
    var maxData = 4096
    private var nextId = 1

    fun connect(onStatus: (String) -> Unit) {
        val itf = adbInterface(dev) ?: throw IOException("El móvil no expone la interfaz ADB. Activa la depuración USB.")
        conn = mgr.openDevice(dev) ?: throw IOException("No se pudo abrir el dispositivo USB")
        if (!conn.claimInterface(itf, true)) throw IOException("No se pudo reclamar la interfaz USB")
        for (j in 0 until itf.endpointCount) {
            val ep = itf.getEndpoint(j)
            if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
            }
        }
        send(A_CNXN, 0x01000001, 256 * 1024, "host::\u0000".toByteArray())
        var sentSig = false
        var sentKey = false
        val deadline = System.currentTimeMillis() + 120_000
        while (System.currentTimeMillis() < deadline) {
            val m = recvOrNull(2000) ?: continue
            if (m.cmd == A_CNXN) {
                maxData = minOf(m.a1, 65536).coerceAtLeast(4096)
                return
            }
            if (m.cmd == A_AUTH && m.a0 == 1) {
                if (!sentSig) {
                    send(A_AUTH, 2, 0, AdbKey.sign(key, m.data))
                    sentSig = true
                } else if (!sentKey) {
                    send(A_AUTH, 3, 0, AdbKey.publicKeyBlob(key))
                    sentKey = true
                    onStatus("Acepta la depuración USB en el otro móvil")
                } else {
                    send(A_AUTH, 3, 0, AdbKey.publicKeyBlob(key))
                }
            }
        }
        throw IOException("Tiempo agotado esperando la autorización del otro móvil")
    }

    fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray = ByteArray(0)) {
        var sum = 0
        for (b in data) sum += b.toInt() and 0xFF
        val bb = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(cmd); bb.putInt(a0); bb.putInt(a1)
        bb.putInt(data.size); bb.putInt(sum); bb.putInt(cmd xor -1)
        writeRaw(bb.array())
        if (data.isNotEmpty()) writeRaw(data)
    }

    private fun writeRaw(b: ByteArray) {
        var off = 0
        while (off < b.size) {
            val n = minOf(16384, b.size - off)
            val r = conn.bulkTransfer(outEp, b, off, n, 5000)
            if (r < 0) throw IOException("Error al escribir por USB")
            off += r
        }
    }

    fun recvOrNull(timeout: Int): AdbMsg? {
        val h = ByteArray(24)
        val n = conn.bulkTransfer(inEp, h, 24, timeout)
        if (n != 24) return null
        val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.int; val a0 = bb.int; val a1 = bb.int; val len = bb.int
        val data = ByteArray(len)
        var off = 0
        while (off < len) {
            val r = conn.bulkTransfer(inEp, data, off, minOf(16384, len - off), 5000)
            if (r < 0) throw IOException("Error al leer por USB")
            off += r
        }
        return AdbMsg(cmd, a0, a1, data)
    }

    fun recv(): AdbMsg = recvOrNull(15000) ?: throw IOException("El móvil no responde (USB)")

    private fun open(service: String): AdbStream {
        val id = nextId++
        send(A_OPEN, id, 0, (service + "\u0000").toByteArray())
        while (true) {
            val m = recv()
            if (m.cmd == A_OKAY && m.a1 == id) return AdbStream(this, id, m.a0)
            if (m.cmd == A_CLSE) throw IOException("El móvil rechazó el servicio $service")
        }
    }

    @Synchronized
    fun run(cmd: String): ByteArray {
        val s = open("exec:$cmd")
        val out = ByteArrayOutputStream()
        while (true) {
            val d = s.read() ?: break
            out.write(d)
        }
        return out.toByteArray()
    }

    fun runText(cmd: String): String = String(run(cmd), Charsets.UTF_8).trim()

    private fun req(id: String, s: String): ByteArray {
        val p = s.toByteArray()
        val bb = ByteBuffer.allocate(8 + p.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put(id.toByteArray()); bb.putInt(p.size); bb.put(p)
        return bb.array()
    }

    @Synchronized
    fun list(path: String): List<Entry> {
        val s = open("sync:")
        try {
            s.write(req("LIST", path))
            val r = SyncIn(s)
            val res = ArrayList<Entry>()
            while (true) {
                val id = String(r.bytes(4))
                if (id == "DONE") { r.bytes(16); break }
                if (id != "DENT") throw IOException("Respuesta inesperada")
                val mode = r.int(); val size = r.int(); r.int(); val nl = r.int()
                val name = String(r.bytes(nl), Charsets.UTF_8)
                if (name == "." || name == "..") continue
                res.add(Entry(name, (mode and 0xF000) == 0x4000, size.toLong() and 0xffffffffL))
            }
            return res
        } finally {
            s.close()
        }
    }

    @Synchronized
    fun pull(path: String, out: OutputStream) {
        val s = open("sync:")
        try {
            s.write(req("RECV", path))
            val r = SyncIn(s)
            while (true) {
                val id = String(r.bytes(4))
                val len = r.int()
                when (id) {
                    "DATA" -> out.write(r.bytes(len))
                    "DONE" -> return
                    "FAIL" -> throw IOException(String(r.bytes(len)))
                    else -> throw IOException("Respuesta inesperada")
                }
            }
        } finally {
            s.close()
        }
    }

    @Synchronized
    fun push(path: String, input: InputStream) {
        val s = open("sync:")
        try {
            s.write(req("SEND", "$path,33206"))
            val buf = ByteArray(65536)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                val bb = ByteBuffer.allocate(8 + n).order(ByteOrder.LITTLE_ENDIAN)
                bb.put("DATA".toByteArray()); bb.putInt(n); bb.put(buf, 0, n)
                s.write(bb.array())
            }
            val done = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            done.put("DONE".toByteArray()); done.putInt((System.currentTimeMillis() / 1000).toInt())
            s.write(done.array())
            val r = SyncIn(s)
            val id = String(r.bytes(4))
            val len = r.int()
            if (id == "FAIL") throw IOException(String(r.bytes(len)))
        } finally {
            s.close()
        }
    }
}
