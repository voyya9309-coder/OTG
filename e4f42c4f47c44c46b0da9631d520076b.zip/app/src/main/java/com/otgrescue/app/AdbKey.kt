package com.otgrescue.app

import android.content.Context
import android.util.Base64
import java.io.File
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.RSAPrivateCrtKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAPublicKeySpec

object AdbKey {
    private val SHA1_PREFIX = byteArrayOf(
        0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    )

    fun load(ctx: Context): KeyPair {
        val f = File(ctx.filesDir, "adbkey.der")
        val kf = KeyFactory.getInstance("RSA")
        if (f.exists()) {
            val priv = kf.generatePrivate(PKCS8EncodedKeySpec(f.readBytes())) as RSAPrivateCrtKey
            val pub = kf.generatePublic(RSAPublicKeySpec(priv.modulus, priv.publicExponent))
            return KeyPair(pub, priv)
        }
        val g = KeyPairGenerator.getInstance("RSA")
        g.initialize(2048)
        val kp = g.generateKeyPair()
        f.writeBytes(kp.private.encoded)
        return kp
    }

    fun sign(kp: KeyPair, token: ByteArray): ByteArray {
        val s = Signature.getInstance("NONEwithRSA")
        s.initSign(kp.private)
        s.update(SHA1_PREFIX)
        s.update(token)
        return s.sign()
    }

    private fun putWords(bb: ByteBuffer, v: BigInteger) {
        val mask = BigInteger.ONE.shiftLeft(32).subtract(BigInteger.ONE)
        for (i in 0 until 64) {
            bb.putInt(v.shiftRight(32 * i).and(mask).toLong().toInt())
        }
    }

    fun publicKeyBlob(kp: KeyPair): ByteArray {
        val pub = kp.public as RSAPublicKey
        val n = pub.modulus
        val two32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = n.mod(two32).modInverse(two32).negate().mod(two32)
        val rr = BigInteger.ONE.shiftLeft(4096).mod(n)
        val bb = ByteBuffer.allocate(4 + 4 + 256 + 256 + 4).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(64)
        bb.putInt(n0inv.toLong().toInt())
        putWords(bb, n)
        putWords(bb, rr)
        bb.putInt(pub.publicExponent.toInt())
        val b64 = Base64.encode(bb.array(), Base64.NO_WRAP)
        return b64 + " otgrescue@android".toByteArray() + byteArrayOf(0)
    }
}
